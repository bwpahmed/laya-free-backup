<!-- Copyright 2026 Aayush Chawla -->
<!-- SPDX-License-Identifier: Apache-2.0 -->
<script lang="ts">
	import type { ActionCard, CardEgressContext, CardEgressAction, Tag, TagAssignment } from '$lib/api/types';
	import { engineApi } from '$lib/api/engine';
	import { goto } from '$app/navigation';
	import { untrack } from 'svelte';
	import { chatOpen, chatCardContext, chatCardIds, chatListOpen } from '$lib/stores/chat';
	import { buildSingleCardContext } from '$lib/utils/cardContext';
	import { parseBackendDate } from '$lib/utils/datetime';
	import { PRIORITY_LABELS, PRIORITY_COLORS } from '$lib/utils/cardVisuals';
	import { lastMessage } from '$lib/stores/websocket';
	import MarkdownRender from '$lib/components/MarkdownRender.svelte';
	import ClassificationDialog from './ClassificationDialog.svelte';
	import OriginalContentModal from './OriginalContentModal.svelte';
	import PlatformBadge from '$lib/components/PlatformBadge.svelte';
	import { glassTheme } from '$lib/stores/glassTheme';
	import { portal } from '$lib/actions/portal';
	import { compose } from '$lib/stores/compose';
	import { detailExpanded } from '$lib/stores/detailPanel';
	import { spaces, loadSpaces } from '$lib/stores/spaces';

	let {
		card,
		onclose,
		ondismiss,
		ongotocard,
		onlink,
		onshowrelated,
		onunlinked,
		onrunagent,
	}: { card: ActionCard; onclose: () => void; ondismiss?: () => void; ongotocard?: (card: ActionCard) => void; onlink?: (card: ActionCard) => void; onshowrelated?: (card: ActionCard) => void; onunlinked?: (cardId: string, entityId: string) => void; onrunagent?: (entityId: string) => void } = $props();

	let markingDone = $state(false);
	let dismissing = $state(false);
	let archiving = $state(false);
	let reopening = $state(false);
	let reprocessing = $state(false);
	let copied = $state(false);
	let dismissReason = $state('');
	let showDismissInput = $state(false);
	let executingActionId = $state<string | null>(null);
	let executeError = $state<string | null>(null);
	let editingActionId = $state<string | null>(null);
	let editedPayload = $state<Record<string, string>>({});
	let savingPayload = $state(false);
	// Per-action spinner state for AI Polish. Seeded from `_polishing` flags
	// persisted in the action payload, so re-mounting the panel mid-flight
	// still shows the spinner. WS `action_payload_updated` events keep it
	// in sync across navigations and clients.
	let polishingActionIds = $state(new Set<string>());
	let polishErrors = $state<Record<string, string>>({});
	let showDeleteConfirm = $state(false);
	let deleting = $state(false);
	let showClassificationDialog = $state(false);
	let showOriginalModal = $state(false);
	let bookmarking = $state(false);
	let unlinkingCard = $state(false);
	let showRunAgentInput = $state(false);
	let runAgentPrompt = $state('');
	let startingAgent = $state(false);
	let actorTruncated = $state(false);
	let emailTruncated = $state(false);
	let relatedCount = $state<number | null>(null);
	let loadingRelated = $state(false);
	let overflowMenuOpen = $state(false);
	let overflowBtnEl: HTMLElement | undefined = $state();
	let overflowMenuEl: HTMLElement | undefined = $state();
	let overflowMenuPos = $state({ top: 0, right: 0 });
	// Separate header overflow menu — collapses the header icon row (everything
	// except the close button) so the card panel header stays uncluttered.
	let headerMenuOpen = $state(false);
	let headerMenuBtnEl: HTMLElement | undefined = $state();
	let headerMenuEl: HTMLElement | undefined = $state();
	let headerMenuPos = $state({ top: 0, right: 0 });
	let fixedTooltip = $state<{ text: string; top: number; left: number } | null>(null);

	// Move-to-space: an inline footer action (lowest priority — the first that would
	// collapse into overflow) that reparents the card's whole GROUP to another space.
	let moveMenuOpen = $state(false);
	let moveBtnEl: HTMLElement | undefined = $state();
	let moveMenuEl: HTMLElement | undefined = $state();
	let moveMenuPos = $state({ top: 0, right: 0 });
	let moveConfirm = $state<null | { space_id: string; space_name: string; warning: string; scope: string; count: number }>(null);
	let moving = $state(false);

	// Load spaces once so the picker knows the alternatives (store is cheap/cached).
	$effect(() => { loadSpaces(); });

	const otherSpaces = $derived($spaces.filter((s) => s.space_id !== (card.space_id ?? 'default')));

	$effect(() => {
		if (!moveMenuOpen) return;
		function handleClick(e: MouseEvent) {
			const target = e.target as HTMLElement;
			if (!moveMenuEl?.contains(target) && !moveBtnEl?.contains(target)) {
				moveMenuOpen = false;
			}
		}
		document.addEventListener('click', handleClick, true);
		return () => document.removeEventListener('click', handleClick, true);
	});

	function toggleMoveMenu() {
		if (moveMenuOpen) { moveMenuOpen = false; return; }
		if (!moveBtnEl) return;
		const rect = moveBtnEl.getBoundingClientRect();
		moveMenuPos = { top: rect.top - 4, right: window.innerWidth - rect.right };
		moveMenuOpen = true;
	}

	// Pick a target space → dry-run the move so the backend tells us the true scope
	// (entity/context group vs standalone) + the warning to confirm.
	async function pickMoveSpace(spaceId: string, spaceName: string) {
		moveMenuOpen = false;
		try {
			const preview = await engineApi.moveCard(card.card_id, { space_id: spaceId, dry_run: true });
			moveConfirm = {
				space_id: spaceId,
				space_name: preview.space_name ?? spaceName,
				warning: preview.warning ?? `Move this card to “${spaceName}”?`,
				scope: preview.scope ?? 'standalone',
				count: preview.card_count ?? 1,
			};
		} catch {
			moveConfirm = { space_id: spaceId, space_name: spaceName, warning: `Move this card to “${spaceName}”?`, scope: 'standalone', count: 1 };
		}
	}

	async function confirmMove() {
		if (!moveConfirm) return;
		moving = true;
		try {
			await engineApi.moveCard(card.card_id, { space_id: moveConfirm.space_id });
			moveConfirm = null;
			// The card (and its group) left the current space; the WS card_updated
			// broadcast re-filters the feed. Close the panel since it's no longer in view.
			onclose();
		} catch {
			// Keep the dialog open on failure so the user can retry / cancel.
		} finally {
			moving = false;
		}
	}

	function showTooltip(el: HTMLElement, text: string) {
		const rect = el.getBoundingClientRect();
		fixedTooltip = { text, top: rect.bottom + 4, left: rect.left + rect.width / 2 };
	}

	function hideTooltip() { fixedTooltip = null; }
	const hasRelated = $derived(relatedCount != null && relatedCount > 0);

	let egressContext = $state<CardEgressContext | null>(null);
	let egressLoading = $state(false);

	// Tags state
	let cardTags = $state<TagAssignment[]>([]);
	let allTags = $state<Tag[]>([]);
	let tagInput = $state('');
	let showTagDropdown = $state(false);
	let addingTag = $state(false);
	let tagInputEl: HTMLInputElement | undefined = $state();
	let tagDropdownPos = $state({ top: 0, left: 0 });

	function updateTagDropdownPos() {
		if (tagInputEl) {
			const r = tagInputEl.getBoundingClientRect();
			tagDropdownPos = { top: r.bottom + 4, left: r.left };
		}
	}

	$effect(() => {
		if (!showTagDropdown || !tagInputEl) return;
		let raf: number;
		function tick() {
			updateTagDropdownPos();
			raf = requestAnimationFrame(tick);
		}
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	});

	const currentCardTags = $derived(card.tags ?? []);
	$effect(() => {
		cardTags = currentCardTags;
	});
	$effect(() => {
		engineApi.listTags().then(r => { allTags = r.tags; }).catch(() => {});
	});

	const filteredTags = $derived(
		tagInput.trim()
			? allTags.filter(t =>
				t.name.toLowerCase().includes(tagInput.toLowerCase()) &&
				!cardTags.some(ct => ct.tag_id === t.tag_id)
			).slice(0, 5)
			: allTags.filter(t => !cardTags.some(ct => ct.tag_id === t.tag_id)).slice(0, 5)
	);

	async function addTag(nameOrId: string | number) {
		addingTag = true;
		try {
			const result = await engineApi.assignTag({
				tag_name_or_id: nameOrId,
				target_type: 'card',
				target_id: card.card_id,
				create_if_missing: true
			});
			const matchedTag = allTags.find(t => t.tag_id === result.tag_id);
			cardTags = [...cardTags, {
				tag_id: result.tag_id,
				tag_name: result.tag_name,
				color: matchedTag?.color,
				is_system: matchedTag?.is_system ?? false,
				assigned_by: 'user'
			}];
			tagInput = '';
			showTagDropdown = false;
			// Refresh available tags in case a new one was created
			engineApi.listTags().then(r => { allTags = r.tags; }).catch(() => {});
		} catch { /* handled silently */ }
		addingTag = false;
	}

	async function removeTag(tagId: number) {
		try {
			await engineApi.removeTag({ tag_id: tagId, target_type: 'card', target_id: card.card_id });
			cardTags = cardTags.filter(t => t.tag_id !== tagId);
		} catch { /* handled silently */ }
	}

	// Guard the related/egress fetches on the card_id actually changing. The `card`
	// prop is replaced with a fresh object on every WS status tick of the selected
	// card (same card_id, new identity), which re-ran these effects and refetched
	// related + egress context each time (review §2 UI — P4-34). Skip when the
	// card_id is unchanged.
	let _relatedFor: string | null = null;
	$effect(() => {
		const cardId = card.card_id;
		if (_relatedFor === cardId) return;
		_relatedFor = cardId;
		relatedCount = null;
		if (!onshowrelated) return;
		loadingRelated = true;
		engineApi.getRelatedCards(cardId).then((data) => {
			if (card.card_id === cardId) {
				relatedCount = data.total_related_cards;
			}
		}).catch(() => {}).finally(() => { loadingRelated = false; });
	});

	let _egressFor: string | null = null;
	$effect(() => {
		const cardId = card.card_id;
		const entityId = card.entity_id;
		if (_egressFor === cardId) return;
		_egressFor = cardId;
		egressContext = null;
		egressLoading = false;
		if (!entityId) return;
		egressLoading = true;
		engineApi.getCardEgressContext(cardId).then((ctx) => {
			if (card.card_id === cardId) egressContext = ctx;
		}).catch(() => {
			egressContext = null;
		}).finally(() => { egressLoading = false; });
	});

	$effect(() => {
		if (!overflowMenuOpen) return;
		function handleClick(e: MouseEvent) {
			const target = e.target as HTMLElement;
			if (!overflowMenuEl?.contains(target) && !overflowBtnEl?.contains(target)) {
				overflowMenuOpen = false;
			}
		}
		document.addEventListener('click', handleClick, true);
		return () => document.removeEventListener('click', handleClick, true);
	});

	function toggleOverflowMenu() {
		if (overflowMenuOpen) { overflowMenuOpen = false; return; }
		if (!overflowBtnEl) return;
		const rect = overflowBtnEl.getBoundingClientRect();
		overflowMenuPos = { top: rect.top - 4, right: window.innerWidth - rect.right };
		overflowMenuOpen = true;
	}

	$effect(() => {
		if (!headerMenuOpen) return;
		function handleClick(e: MouseEvent) {
			const target = e.target as HTMLElement;
			if (!headerMenuEl?.contains(target) && !headerMenuBtnEl?.contains(target)) {
				headerMenuOpen = false;
			}
		}
		document.addEventListener('click', handleClick, true);
		return () => document.removeEventListener('click', handleClick, true);
	});

	function toggleHeaderMenu() {
		if (headerMenuOpen) { headerMenuOpen = false; return; }
		if (!headerMenuBtnEl) return;
		const rect = headerMenuBtnEl.getBoundingClientRect();
		// Header sits at the top of the panel, so the menu drops *below* the trigger.
		headerMenuPos = { top: rect.bottom + 4, right: window.innerWidth - rect.right };
		headerMenuOpen = true;
	}

	function openPlatformAction(action: CardEgressAction) {
		if (!egressContext) return;
		overflowMenuOpen = false;
		compose.openCompose(
			egressContext.platform,
			action.action_type,
			egressContext.prefill,
			card.card_id,
			egressContext.event_id ?? undefined,
			egressContext.connection_id
		);
	}

	// Watches an element for text overflow and reports the result via callback.
	// The text param is included so the action's `update` re-runs (and re-measures)
	// when the underlying text changes — ResizeObserver alone fires only on size changes,
	// so it would miss a shorter string fitting after a card switch.
	function trackTruncation(node: HTMLElement, params: { onChange: (t: boolean) => void; text: string }) {
		let { onChange } = params;
		const measure = () => onChange(node.scrollWidth > node.clientWidth + 1);
		measure();
		const ro = new ResizeObserver(measure);
		ro.observe(node);
		return {
			update(next: { onChange: (t: boolean) => void; text: string }) {
				onChange = next.onChange;
				queueMicrotask(measure);
			},
			destroy() { ro.disconnect(); }
		};
	}

	async function unlinkCard() {
		unlinkingCard = true;
		try {
			await engineApi.unlinkRelatedCard(card.card_id);
			const entityId = card.entity_id ?? '';
			overflowMenuOpen = false;
			onunlinked?.(card.card_id, entityId);
			try {
				const data = await engineApi.getRelatedCards(card.card_id);
				relatedCount = data.total_related_cards;
			} catch {
				relatedCount = 0;
			}
		} finally {
			unlinkingCard = false;
		}
	}

	const priorityColors = PRIORITY_COLORS;

	const priorityLabel = PRIORITY_LABELS;

	const personaColors: Record<string, string> = {
		ENGINEER: 'border-violet-500 text-violet-400',
		COMMS: 'border-emerald-500 text-emerald-400',
		OPS: 'border-amber-500 text-amber-400',
		SALES: 'border-sky-500 text-sky-400',
		HR: 'border-rose-500 text-rose-400',
		FINANCE: 'border-teal-500 text-teal-400'
	};

	const outputTypeLabels: Record<string, string> = {
		draft_reply: 'Draft Reply',
		code_fix: 'Code Fix',
		briefing: 'Briefing',
		summary: 'Summary',
		agent_result: 'Agent Result',
		agent_plan: 'Implementation Plan'
	};

	const terminalStatuses = new Set(['done', 'failed', 'dismissed', 'archived']);
	const actionableStatuses = new Set(['ready', 'agent_running', 'awaiting_input']);
	let isActionable = $derived(actionableStatuses.has(card.status));
	let isTerminal = $derived(terminalStatuses.has(card.status));

	const statusColors: Record<string, string> = {
		pending: 'text-yellow-400',
		ready: 'text-amber-400',
		agent_running: 'text-violet-400',
		awaiting_input: 'text-violet-400',
		done: 'text-green-500',
		failed: 'text-red-500',
		dismissed: 'text-surface-500',
		archived: 'text-surface-600'
	};

	const statusLabels: Record<string, string> = {
		pending: 'Processing',
		ready: 'Ready',
		agent_running: 'Agent Running',
		awaiting_input: 'Input Needed',
		done: 'Done',
		failed: 'Failed',
		dismissed: 'Dismissed',
		archived: 'Archived'
	};

	async function executeAction(actionId: string) {
		executingActionId = actionId;
		card.selected_action_id = actionId;
		executeError = null;
		try {
			const mods = editingActionId === actionId && Object.keys(editedPayload).length > 0
				? editedPayload
				: undefined;
			const result = await engineApi.executeAction(card.card_id, actionId, mods);
			card.status = result.status as ActionCard['status'];
			if (result.error) {
				card.last_error = result.error;
			} else {
				card.last_error = undefined;
			}
			if (result.result_url && result.status === 'done') {
				const action = card.suggested_actions?.find(a => a.action_id === actionId);
				if (action?.action_type === 'open_url') {
					try {
						const { open } = await import('@tauri-apps/plugin-shell');
						await open(result.result_url);
					} catch {
						window.open(result.result_url, '_blank', 'noopener,noreferrer');
					}
				}
			}
			editingActionId = null;
			editedPayload = {};
		} catch (err) {
			executeError = err instanceof Error ? err.message : 'Execution failed';
		} finally {
			executingActionId = null;
		}
	}

	/** Identify the main editable text field in an action payload (body, comment, message, etc.). */
	function getEditableTextField(payload: Record<string, unknown>): string | null {
		for (const key of ['body', 'comment', 'message', 'description']) {
			if (typeof payload[key] === 'string' && (payload[key] as string).length > 0) return key;
		}
		return null;
	}

	function startEditing(
		action: { action_id: string; payload: Record<string, unknown> },
		fallbackBody?: string
	) {
		editingActionId = action.action_id;
		const p = action.payload;
		// Extract all string fields for editing — works for email (to/subject/body),
		// Bitbucket/GitHub (comment), Slack (message), Jira (comment), etc.
		// Skip underscore-prefixed keys (e.g. _edited, _polishing, _polish_error)
		// which are internal UI-state flags, not user-editable content.
		editedPayload = {};
		for (const [key, value] of Object.entries(p)) {
			if (key.startsWith('_')) continue;
			if (typeof value === 'string' && value.length > 0) {
				editedPayload[key] = value;
			}
		}
		// When the engine couldn't parse the LLM's payload (it arrives as
		// `{raw: "subject"}` because the model emitted a non-JSON string), the
		// action has no body/comment field but the actual draft text still lives
		// in staged_output.content. Seed `body` so the user can edit + save and
		// the next executor pass has something usable to send.
		if (fallbackBody && !editedPayload.body && !editedPayload.comment && !editedPayload.message && !editedPayload.description) {
			editedPayload.body = fallbackBody;
		}
	}

	async function polishDraft(action: { action_id: string }) {
		if (polishingActionIds.has(action.action_id)) return;
		// Optimistic spinner — confirmed by the WS echo once the server flips
		// `_polishing` to true, then cleared when polish completes.
		polishingActionIds = new Set([...polishingActionIds, action.action_id]);
		const { [action.action_id]: _drop, ...restErrors } = polishErrors;
		polishErrors = restErrors;
		try {
			await engineApi.polishActionPayload(card.card_id, action.action_id);
		} catch (err) {
			const next = new Set(polishingActionIds);
			next.delete(action.action_id);
			polishingActionIds = next;
			polishErrors = {
				...polishErrors,
				[action.action_id]: err instanceof Error ? err.message : 'Polish failed'
			};
		}
	}

	// Seed spinner state from persisted `_polishing` flags whenever the viewed
	// card changes (fresh panel mount, or user switches cards). The WS effect
	// below handles subsequent updates — so we don't re-seed on every mutation,
	// which would otherwise wipe client-side errors from failed API calls.
	let _seededCardId = $state<string | null>(null);
	$effect(() => {
		if (_seededCardId === card.card_id) return;
		_seededCardId = card.card_id;
		const actions = card.suggested_actions ?? [];
		const seed = new Set<string>();
		const errs: Record<string, string> = {};
		for (const a of actions) {
			const p = a.payload as Record<string, unknown> | undefined;
			if (p?._polishing === true) seed.add(a.action_id);
			if (typeof p?._polish_error === 'string') errs[a.action_id] = p._polish_error as string;
		}
		polishingActionIds = seed;
		polishErrors = errs;
	});

	// Listen for per-action payload updates (polish start/complete, manual save).
	// The feed's WS handler is responsible for mutating groups[] — this handler
	// ONLY updates local spinner/error state.
	//
	// The body runs inside untrack() so the effect depends only on $lastMessage.
	// Without untrack, reading card.suggested_actions / action.payload here
	// tracks those reactive proxies; the subsequent writes to action.payload
	// then re-trigger this same effect, loop without bound, starve the
	// microtask queue, and freeze the UI (blocking savePayload's finally, so
	// "Saving..." never clears, and blocking any navigation after Polish).
	$effect(() => {
		const msg = $lastMessage;
		if (!msg || msg.type !== 'action_payload_updated') return;
		untrack(() => {
			if (msg.card_id !== card.card_id) return;
			const actionId = (msg as { action_id?: string }).action_id;
			const newPayload = (msg.payload as { payload?: Record<string, unknown> })?.payload;
			if (!actionId || !newPayload) return;
			if (newPayload._polishing === true) {
				polishingActionIds = new Set([...polishingActionIds, actionId]);
			} else if (newPayload._polishing === false) {
				const next = new Set(polishingActionIds);
				next.delete(actionId);
				polishingActionIds = next;
			}
			const err = newPayload._polish_error;
			if (typeof err === 'string' && err) {
				polishErrors = { ...polishErrors, [actionId]: err };
			} else if (newPayload._polishing === false && actionId in polishErrors) {
				const { [actionId]: _drop, ...rest } = polishErrors;
				polishErrors = rest;
			}
		});
	});

	async function savePayload(action: { action_id: string; payload: Record<string, unknown> }) {
		savingPayload = true;
		try {
			await engineApi.updateActionPayload(card.card_id, action.action_id, editedPayload);
			// Update the local action payload so the read-only view reflects saved
			// changes. Also flip _edited locally so the Polish button appears
			// immediately — the WS echo will confirm this shortly.
			Object.assign(action.payload, editedPayload);
			action.payload._edited = true;
			editingActionId = null;
			editedPayload = {};
		} catch (err) {
			executeError = err instanceof Error ? err.message : 'Failed to save draft';
		} finally {
			savingPayload = false;
		}
	}

	async function markDone() {
		markingDone = true;
		try {
			await engineApi.markCardDone(card.card_id);
			card.status = 'done';
		} finally {
			markingDone = false;
		}
	}

	async function dismiss() {
		dismissing = true;
		try {
			await engineApi.dismissCard(card.card_id, dismissReason || undefined);
			card.status = 'dismissed';
			showDismissInput = false;
		} finally {
			dismissing = false;
		}
	}

	async function archive() {
		archiving = true;
		try {
			await engineApi.archiveCard(card.card_id);
			card.status = 'archived';
		} finally {
			archiving = false;
		}
	}

	async function reopen() {
		reopening = true;
		try {
			const result = await engineApi.reopenCard(card.card_id);
			card.status = result.status as ActionCard['status'];
		} finally {
			reopening = false;
		}
	}

	async function reprocess() {
		headerMenuOpen = false;
		if (reprocessing) return;
		reprocessing = true;
		try {
			await engineApi.reprocessCard(card.card_id);
			// Reflect the reprocess immediately; the WS card_updated stream drives
			// the card back through provisional → ready as the pipeline re-runs.
			card.status = 'pending';
		} catch (e) {
			console.error('Reprocess failed:', e);
		} finally {
			reprocessing = false;
		}
	}

	function deleteCard() {
		// Optimistic: close immediately, fire API in background
		showDeleteConfirm = false;
		onclose();
		engineApi.deleteCard(card.card_id).catch(() => {
			// If delete fails, next WS reload will restore the card
		});
	}

	async function toggleBookmark() {
		bookmarking = true;
		try {
			if (card.bookmarked_at) {
				await engineApi.unbookmarkCard(card.card_id);
				card.bookmarked_at = undefined;
			} else {
				const result = await engineApi.bookmarkCard(card.card_id);
				card.bookmarked_at = result.bookmarked_at;
			}
		} finally {
			bookmarking = false;
		}
	}

	async function copyId() {
		await navigator.clipboard.writeText(card.card_id);
		copied = true;
		setTimeout(() => (copied = false), 1500);
	}

	function chatAbout() {
		chatCardContext.set(buildSingleCardContext(card));
		chatCardIds.set([card.card_id]);
		chatListOpen.set(false);
		chatOpen.set(true);
	}

	async function startEntityAgent() {
		if (!card.entity_id || !onrunagent) return;
		startingAgent = true;
		try {
			await engineApi.runEntityAgent(card.entity_id, {
				prompt: runAgentPrompt || undefined
			});
			card.has_workspace = true;
			showRunAgentInput = false;
			runAgentPrompt = '';
		} finally {
			startingAgent = false;
		}
	}
</script>

<!-- In focus mode ($detailExpanded) the overlay wrapper provides the panel surface,
     so we drop our own card chrome to avoid a doubled border/background. -->
<div class="flex h-full flex-col overflow-hidden {$detailExpanded ? '' : ($glassTheme ? 'rounded-xl border glass-card border-surface-700/40 bg-surface-900/40' : 'rounded-xl border border-surface-700 bg-surface-800')}">
	<!-- Header bar -->
	<div class="flex items-center justify-between border-b px-5 py-4 {$glassTheme ? 'border-surface-700/40' : 'border-surface-700'}">
		<div class="flex items-center gap-2">
			<span class="rounded px-1.5 py-0.5 text-laya-micro font-bold uppercase {priorityColors[card.priority] ?? priorityColors.MEDIUM}">
				{priorityLabel[card.priority] ?? card.priority}
			</span>
			<span class="rounded border px-1.5 py-0.5 text-laya-micro font-medium uppercase {personaColors[card.persona] ?? personaColors.ENGINEER}">
				{card.persona}
			</span>
			{#if card.privacy_tier === 3}
				<span class="rounded bg-red-900/50 px-1.5 py-0.5 text-laya-micro font-medium text-red-300">
					CONFIDENTIAL
				</span>
			{/if}
		</div>
		<div class="flex items-center gap-1">
			<!-- Overflow menu — collapses all header actions except close -->
			<button
				bind:this={headerMenuBtnEl}
				onclick={toggleHeaderMenu}
				onmouseenter={(e) => showTooltip(e.currentTarget, 'More actions')}
				onmouseleave={hideTooltip}
				aria-label="More actions"
				class="rounded p-1.5 transition-colors {headerMenuOpen ? 'text-surface-200' : 'text-surface-500 hover:text-surface-200'}"
			>
				<svg class="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
					<path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM18 10a2 2 0 11-4 0 2 2 0 014 0z" />
				</svg>
			</button>
			<!-- Expand / collapse the wide focus-mode overlay (same as the chat sidebar). -->
			<button
				onclick={() => detailExpanded.set(!$detailExpanded)}
				onmouseenter={(e) => showTooltip(e.currentTarget, $detailExpanded ? 'Collapse' : 'Expand')}
				onmouseleave={hideTooltip}
				aria-label={$detailExpanded ? 'Collapse panel' : 'Expand panel'}
				class="rounded p-1.5 text-surface-500 transition-colors hover:text-surface-200"
			>
				{#if $detailExpanded}
					<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 9h5V4M20 9h-5V4M4 15h5v5M20 15h-5v5" />
					</svg>
				{:else}
					<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 4H4v5M15 4h5v5M9 20H4v-5M15 20h5v-5" />
					</svg>
				{/if}
			</button>
			<button aria-label="Close panel" class="rounded p-1.5 text-surface-400 transition-colors hover:text-surface-100" onclick={() => ondismiss ? ondismiss() : onclose()}>
				<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
		</div>
	</div>

	<!-- Scrollable content -->
	<div class="flex-1 overflow-y-auto overflow-x-hidden break-words px-5 py-4">
		<!-- Source platform + subject ID + actor info -->
		{#if card.entity_id || card.actor_name || card.actor_email}
			<div class="mb-3 flex flex-col gap-0.5">
				{#if card.entity_id}
					<div class="mb-1 flex items-center gap-1.5 min-w-0">
						<PlatformBadge platform={card.entity_id.split(':')[0]} />
						{#if card.source_context}
							<span class="text-laya-secondary text-surface-400">{card.source_context}</span>
						{/if}
						{#if card.source_ref}
							{#if card.source_url}
								<a
									href={card.source_url}
									target="_blank"
									rel="noopener noreferrer"
									class="inline-flex items-center gap-1 text-laya-secondary font-medium text-laya-orange hover:text-laya-peach transition-colors min-w-0 truncate"
								>
									<span class="truncate">{card.source_ref}</span>
									<svg class="h-2.5 w-2.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
									</svg>
								</a>
							{:else}
								<span class="text-laya-secondary font-medium text-surface-400 truncate">{card.source_ref}</span>
							{/if}
						{/if}
					</div>
				{/if}
				{#if card.actor_name}
					<div class="flex items-center gap-1.5 min-w-0">
						<span class="shrink-0 text-laya-micro font-semibold uppercase tracking-wider text-surface-500">Actor</span>
						<span class="group/actor relative min-w-0 flex-1">
							<span use:trackTruncation={{ onChange: (t) => (actorTruncated = t), text: card.actor_name }} class="block truncate text-laya-secondary text-surface-300">{card.actor_name}</span>
							{#if actorTruncated}
								<span class="pointer-events-none absolute left-0 top-full z-50 mt-1 max-w-xs break-all whitespace-normal rounded-md border border-transparent glass-tooltip px-2 py-1 text-laya-micro font-medium opacity-0 transition-opacity duration-75 group-hover/actor:opacity-100">
									{card.actor_name}
								</span>
							{/if}
						</span>
					</div>
				{/if}
				{#if card.actor_email}
					<div class="flex items-center gap-1.5 min-w-0">
						<span class="shrink-0 text-laya-micro font-semibold uppercase tracking-wider text-surface-500">Email</span>
						<span class="group/email relative min-w-0 flex-1">
							<span use:trackTruncation={{ onChange: (t) => (emailTruncated = t), text: card.actor_email }} class="block truncate text-laya-secondary text-surface-400">{card.actor_email}</span>
							{#if emailTruncated}
								<span class="pointer-events-none absolute left-0 top-full z-50 mt-1 max-w-xs break-all whitespace-normal rounded-md border border-transparent glass-tooltip px-2 py-1 text-laya-micro font-medium opacity-0 transition-opacity duration-75 group-hover/email:opacity-100">
									{card.actor_email}
								</span>
							{/if}
						</span>
					</div>
				{/if}
			</div>
		{/if}

		<!-- Header + summary -->
		<h2 class="mb-2 text-laya-heading font-semibold text-surface-50">{card.header}</h2>
		<p class="mb-5 text-laya-base text-surface-300">{card.summary}</p>

		<!-- Tags -->
		<div class="mb-5">
			<div class="flex flex-wrap items-center gap-1.5">
				{#each cardTags as tag}
					<span
						class="{tag.is_system ? 'tag-chip-system' : 'tag-chip-user'} inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium"
						style="--tag-color: {tag.color ?? (tag.is_system ? '#6B7280' : '#C4956B')}"
					>
						{tag.tag_name}
						{#if !tag.is_system}
							<button
								class="ml-0.5 hover:opacity-70 cursor-pointer"
								title="Remove tag"
								onclick={() => removeTag(tag.tag_id)}
							>
								<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
								</svg>
							</button>
						{/if}
					</span>
				{/each}
				<div class="relative">
					<input
						bind:this={tagInputEl}
						type="text"
						class="h-6 w-24 rounded-full border border-surface-600/50 bg-transparent px-2 text-xs text-surface-300 placeholder-surface-500 outline-none focus:border-laya-orange/50 focus:w-36 transition-all"
						placeholder="Add tag..."
						bind:value={tagInput}
						onfocus={() => { showTagDropdown = true; }}
						onblur={() => { setTimeout(() => { showTagDropdown = false; }, 150); }}
						onkeydown={(e) => {
							if (e.key === 'Enter' && tagInput.trim()) {
								e.preventDefault();
								addTag(tagInput.trim());
							}
						}}
						disabled={addingTag || cardTags.length >= 10}
					/>
				</div>
			</div>
		</div>

		<!-- Intelligence report -->
		{#if card.intelligence && card.intelligence.length > 0}
			<div class="mb-5">
				<h3 class="mb-2 text-laya-secondary font-semibold uppercase tracking-wider text-surface-400">Intelligence Report</h3>
				<ul class="space-y-1.5">
					{#each card.intelligence as point}
						<li class="flex items-start gap-2 text-laya-base text-surface-300 min-w-0">
							<span class="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-surface-500"></span>
							<span class="min-w-0 break-words">{point}</span>
						</li>
					{/each}
				</ul>
			</div>
		{/if}

		<!-- Staged output. Skipped for draft_reply when there's a suggested action —
		     the editable preview below renders the same draft text with Edit/Polish
		     controls, so we'd otherwise duplicate the same content. -->
		{#if card.staged_output && !(card.staged_output.type === 'draft_reply' && (card.suggested_actions?.length ?? 0) > 0)}
			<div class="mb-5">
				<h3 class="mb-2 text-laya-secondary font-semibold uppercase tracking-wider text-surface-400">
					{outputTypeLabels[card.staged_output.type] ?? 'Output'}
				</h3>
				{#if card.staged_output.type === 'code_fix'}
					<pre class="overflow-x-auto rounded-lg bg-surface-900 p-3 text-laya-secondary text-surface-200">{card.staged_output.content}</pre>
				{:else if card.staged_output.type === 'agent_plan'}
					<MarkdownRender
						content={card.staged_output.content}
						class="max-h-96 overflow-y-auto rounded-lg border border-surface-700 bg-surface-900/50 p-4 text-laya-base text-surface-200"
					/>
				{:else}
					<MarkdownRender
						content={card.staged_output.content}
						class="max-h-96 overflow-y-auto overflow-x-auto rounded-lg border border-surface-700 bg-surface-900/50 p-4 text-laya-base text-surface-200"
					/>
				{/if}
			</div>
		{/if}

		<!-- Suggested actions -->
		{#if card.suggested_actions && card.suggested_actions.length > 0}
			<div class="mb-5">
				<h3 class="mb-2 text-laya-secondary font-semibold uppercase tracking-wider text-surface-400">Suggested Actions</h3>
				{#each card.suggested_actions as action}
					{@const isSelected = card.selected_action_id === action.action_id}
					{@const payload = action.payload}
					{@const detectedField = payload ? getEditableTextField(payload) : null}
					{@const isDraftReply = card.staged_output?.type === 'draft_reply'}
					{@const fallbackText = isDraftReply && detectedField === null && payload?.raw ? (card.staged_output?.content ?? '') : ''}
					{@const editableField = detectedField ?? (fallbackText ? 'body' : null)}
					{@const displayText = (detectedField ? (payload[detectedField] as string) : fallbackText) ?? ''}

					<!-- Action payload preview — works for any action with editable text (email body, PR comment, Slack message, etc.).
					     When the engine couldn't parse the LLM's payload (it landed as `{raw: "..."}` because the model
					     emitted a non-JSON string), `detectedField` is null but the actual draft still lives in
					     `staged_output.content` for draft_reply cards — fall back to it so Edit/Polish stay available. -->
					{#if editableField && displayText}
						{@const isEditing = editingActionId === action.action_id}
						{@const isPolishing = polishingActionIds.has(action.action_id)}
						{@const hasEdits = payload._edited === true}
						{@const polishErrorMsg = polishErrors[action.action_id]}
						<div class="relative mb-2 rounded-lg border border-surface-700 bg-surface-900/50 p-3">
							{#if !isEditing}
								<!-- Read-only view: show metadata fields, then the main text. Skip `raw`
								     since it's an engine-side fallback marker, not user content. -->
								{#each Object.entries(payload) as [key, value]}
									{#if !key.startsWith('_') && typeof value === 'string' && value.length > 0 && key !== editableField && key !== 'raw'}
										<div class="mb-1.5 flex items-center gap-1.5 text-laya-secondary">
											<span class="font-medium text-surface-500 capitalize">{key}:</span>
											<span class="text-surface-300">{value}</span>
										</div>
									{/if}
								{/each}
								<div class="max-h-48 overflow-y-auto whitespace-pre-wrap text-laya-base text-surface-200">{displayText}</div>
							{:else}
								<!-- Edit mode: inputs for metadata, textarea for main text -->
								{#each Object.entries(editedPayload) as [key]}
									{#if key !== editableField}
										<div class="mb-1.5 flex items-center gap-1.5 text-laya-secondary">
											<span class="shrink-0 font-medium text-surface-500 capitalize">{key}:</span>
											<input
												type="text"
												class="w-full rounded border border-surface-600 bg-surface-800 px-1.5 py-0.5 text-laya-secondary text-surface-200 outline-none focus:border-laya-orange/50"
												bind:value={editedPayload[key]}
											/>
										</div>
									{/if}
								{/each}
								<textarea
									class="w-full resize-y rounded border border-surface-600 bg-surface-800 p-2 text-laya-base text-surface-200 outline-none focus:border-laya-orange/50"
									rows="6"
									bind:value={editedPayload[editableField]}
								></textarea>
							{/if}
							<!-- Polish-in-flight overlay. Covers payload preview; blocks interaction
							     while the LLM is rewriting. Survives navigation because _polishing
							     is persisted in the action payload. -->
							{#if isPolishing}
								<div class="pointer-events-auto absolute inset-0 flex flex-col items-center justify-center gap-2 rounded-lg bg-surface-900/70 backdrop-blur-sm">
									<svg class="h-6 w-6 animate-spin text-laya-orange" fill="none" viewBox="0 0 24 24">
										<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
										<path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
									</svg>
									<span class="text-laya-secondary font-medium text-laya-orange">Polishing draft…</span>
								</div>
							{/if}
							<!-- Edit / Save / Cancel / Polish controls -->
							{#if !isTerminal}
								<div class="mt-2 flex items-center justify-end gap-3">
									{#if polishErrorMsg && !isPolishing}
										<span class="mr-auto text-laya-secondary text-red-400">{polishErrorMsg}</span>
									{/if}
									{#if !isEditing}
										<button
											class="text-laya-secondary text-surface-400 hover:text-laya-orange transition-colors disabled:opacity-40 disabled:hover:text-surface-400"
											onclick={() => startEditing(action, detectedField ? undefined : fallbackText)}
											disabled={isPolishing}
										>
											Edit draft
										</button>
										{#if hasEdits}
											<button
												class="inline-flex items-center gap-1 text-laya-secondary font-medium text-laya-gold hover:text-laya-peach transition-colors disabled:opacity-40 disabled:hover:text-laya-gold"
												onclick={() => polishDraft(action)}
												disabled={isPolishing}
												title="Rewrite this draft with AI to polish the phrasing"
											>
												<svg class="h-3 w-3" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
													<path d="M12 2l1.9 5.6L19.5 9.5l-5.6 1.9L12 17l-1.9-5.6L4.5 9.5l5.6-1.9L12 2zm7 11l.95 2.8L22.75 16.75l-2.8.95L19 20.5l-.95-2.8L15.25 16.75l2.8-.95L19 13zM5 14l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7L5 14z" />
												</svg>
												Polish
											</button>
										{/if}
									{:else}
										<button
											class="text-laya-secondary text-surface-400 hover:text-surface-200 transition-colors"
											onclick={() => { editingActionId = null; editedPayload = {}; }}
											disabled={savingPayload}
										>
											Cancel
										</button>
										<button
											class="text-laya-secondary font-medium text-laya-orange hover:text-laya-gold transition-colors disabled:opacity-50"
											onclick={() => savePayload(action)}
											disabled={savingPayload}
										>
											{savingPayload ? 'Saving...' : 'Save'}
										</button>
									{/if}
								</div>
							{/if}
						</div>
					{/if}

					<div class="mb-2 flex flex-wrap gap-2">
						<button
							class="rounded-lg border px-3 py-1.5 text-laya-secondary font-medium transition-colors disabled:cursor-not-allowed
								{isSelected
									? isTerminal
										? 'border-laya-orange/50 bg-laya-orange/15 text-laya-orange'
										: 'border-surface-500 border-dashed bg-surface-800/50 text-surface-400'
									: card.selected_action_id && !isSelected
										? isTerminal
											? 'border-surface-700 bg-surface-800/50 text-surface-500 opacity-50'
											: 'border-surface-600 bg-surface-700/50 text-surface-200 hover:bg-surface-600'
										: 'border-surface-600 bg-surface-700/50 text-surface-200 hover:bg-surface-600'}"
							onclick={() => executeAction(action.action_id)}
							disabled={!!executingActionId || isTerminal}
						>
							{#if executingActionId === action.action_id}
								Executing...
							{:else}
								{#if isSelected}
									<span class="mr-1">{isTerminal ? '✓' : '↩'}</span>
								{/if}
								{action.label}
								<span class="ml-1 {isSelected && isTerminal ? 'text-laya-orange/60' : 'text-surface-500'}">({action.target_platform})</span>
							{/if}
						</button>
					</div>
				{/each}
				{#if executeError}
					<p class="mt-2 text-laya-secondary text-red-400">{executeError}</p>
				{/if}
			</div>
		{/if}

		<!-- Metadata -->
		<div class="mt-4 border-t pt-3 {$glassTheme ? 'border-surface-700/40' : 'border-surface-700'}">
			<div class="flex flex-wrap gap-x-4 gap-y-1 text-laya-secondary text-surface-500">
				{#if card.confidence}
					<span>Confidence: {Math.round(card.confidence * 100)}%</span>
				{/if}
				<span>Category: {card.category}</span>
				{#if card.status === 'failed' && card.last_error}
					<span class="{statusColors[card.status]} relative group cursor-help">
						Status: {statusLabels[card.status]}
						<span class="invisible group-hover:visible absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2.5 py-1.5 text-laya-secondary leading-tight bg-surface-800 border border-surface-600 text-surface-300 rounded shadow-lg whitespace-normal max-w-[280px] w-max z-50">
							{card.last_error}
						</span>
					</span>
				{:else}
					<span class={statusColors[card.status] ?? 'text-surface-400'}>Status: {statusLabels[card.status] ?? card.status}</span>
				{/if}
				{#if card.created_at}
					<span>Created: {parseBackendDate(card.created_at)?.toLocaleString()}</span>
				{/if}
			</div>
		</div>
	</div>

	<!-- Footer -->
	<div class="border-t px-5 py-2 {$glassTheme ? 'border-surface-700/40' : 'border-surface-700'}">
		<!-- Secondary actions -->
		<div class="flex items-center justify-end gap-1">
			{#if card.has_workspace}
				<a
					href="/workspace/{card.card_id}"
					class="flex items-center gap-1 rounded-md px-2 py-1 text-laya-secondary text-violet-400/80 transition-colors hover:bg-violet-500/15 hover:text-violet-300"
					onclick={(e) => { e.preventDefault(); e.stopPropagation(); goto(`/workspace/${card.card_id}`); }}
				>
					<svg class="h-3 w-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
					Workspace
				</a>
			{/if}
			<button
				class="flex items-center gap-1 rounded-md px-2 py-1 text-laya-secondary text-surface-400 transition-colors hover:bg-surface-700/50 hover:text-surface-200"
				onclick={() => (showClassificationDialog = true)}
			>
				<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
				Classify
			</button>
			{#if onshowrelated && hasRelated}
				<button
					class="flex items-center gap-1 rounded-md px-2 py-1 text-laya-secondary text-surface-400 transition-colors hover:bg-surface-700/50 hover:text-laya-orange"
					onclick={() => onshowrelated(card)}
				>
					<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="5" cy="12" r="2" stroke-width="2" /><circle cx="19" cy="6" r="2" stroke-width="2" /><circle cx="19" cy="18" r="2" stroke-width="2" /><path stroke-linecap="round" stroke-width="2" d="M7 11l10-4M7 13l10 4" /></svg>
					Related ({relatedCount})
				</button>
			{/if}
			{#if onrunagent && card.entity_id && !card.has_workspace}
				<button
					class="flex items-center gap-1 rounded-md px-2 py-1 text-laya-secondary text-surface-400 transition-colors hover:bg-surface-700/50 hover:text-cyan-400"
					onclick={() => (showRunAgentInput = true)}
				>
					<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
					Run Agent
				</button>
			{/if}
			<!-- Move to space — last inline action (lowest priority; first to overflow) -->
			{#if $spaces.length > 1}
				<button
					bind:this={moveBtnEl}
					class="flex items-center gap-1 rounded-md px-2 py-1 text-laya-secondary text-surface-400 transition-colors hover:bg-surface-700/50 hover:text-laya-orange"
					onclick={toggleMoveMenu}
					aria-label="Move to space"
				>
					<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 13h6m0 0l-2-2m2 2l-2 2" /></svg>
					Move
				</button>
			{/if}
			<!-- Overflow menu: Link / Unlink / Delete -->
			<div class="relative">
				<button
					bind:this={overflowBtnEl}
					class="flex items-center justify-center rounded-md px-1.5 py-1 text-laya-secondary text-surface-400 transition-colors hover:bg-surface-700/50 hover:text-surface-200"
					onclick={toggleOverflowMenu}
					aria-label="More actions"
				>
					<svg class="h-3.5 w-3.5" fill="currentColor" viewBox="0 0 20 20">
						<path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM18 10a2 2 0 11-4 0 2 2 0 014 0z" />
					</svg>
				</button>
			</div>
		</div>

		<!-- Primary actions -->
		<div class="mt-3">
			{#if showRunAgentInput}
				<div class="flex flex-col gap-2">
					<div class="flex items-center gap-2 text-laya-secondary text-surface-400">
						<svg class="h-3.5 w-3.5 text-cyan-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
						Run Agent
					</div>
					<input
						bind:value={runAgentPrompt}
						placeholder="What should the agent focus on? (optional)"
						class="flex-1 rounded-md border border-surface-600 bg-surface-900 px-2 py-1.5 text-laya-secondary text-surface-50 placeholder-surface-500"
					/>
					<div class="flex gap-2">
						<button
							class="flex-1 rounded-md bg-cyan-700/40 px-2 py-1.5 text-laya-secondary font-medium text-cyan-300 transition-colors hover:bg-cyan-700/60 disabled:opacity-50"
							onclick={startEntityAgent}
							disabled={startingAgent}
						>
							{startingAgent ? 'Starting...' : 'Start'}
						</button>
						<button
							class="text-laya-base text-surface-400 hover:text-surface-200"
							onclick={() => { showRunAgentInput = false; runAgentPrompt = ''; }}
						>
							Cancel
						</button>
					</div>
				</div>
			{:else if showDismissInput}
				<div class="flex gap-2">
					<input
						bind:value={dismissReason}
						placeholder="Reason (optional)"
						class="flex-1 rounded-md border border-surface-600 bg-surface-900 px-2 py-1.5 text-laya-secondary text-surface-50 placeholder-surface-500"
					/>
					<button
						class="rounded-md bg-surface-600 px-3 py-1.5 text-laya-secondary font-medium text-surface-200 hover:bg-surface-500"
						onclick={dismiss}
						disabled={dismissing}
					>
						{dismissing ? '...' : 'Confirm'}
					</button>
					<button
						class="text-laya-base text-surface-400 hover:text-surface-200"
						onclick={() => (showDismissInput = false)}
					>
						Cancel
					</button>
				</div>
			{:else if card.status === 'ready'}
				<div class="flex gap-2">
					<button
						class="flex-1 rounded-md bg-green-700/40 px-2 py-1.5 text-laya-secondary font-medium text-green-300 transition-colors hover:bg-green-700/60 disabled:opacity-50"
						onclick={markDone}
						disabled={markingDone}
					>
						{markingDone ? '...' : 'Done'}
					</button>
					<button
						class="flex-1 rounded-md bg-surface-700/50 px-2 py-1.5 text-laya-secondary font-medium text-surface-400 transition-colors hover:bg-surface-700"
						onclick={() => (showDismissInput = true)}
					>
						Dismiss
					</button>
					<button
						class="flex-1 rounded-md bg-surface-700/30 px-2 py-1.5 text-laya-secondary font-medium text-surface-500 transition-colors hover:bg-surface-700 disabled:opacity-50"
						onclick={archive}
						disabled={archiving}
					>
						{archiving ? '...' : 'Archive'}
					</button>
				</div>
			{:else if card.status === 'dismissed' || card.status === 'archived' || card.status === 'done' || card.status === 'failed'}
				<div class="flex gap-2">
					<button
						class="flex-1 rounded-md bg-laya-orange/15 px-2 py-1.5 text-laya-secondary font-medium text-laya-orange transition-colors hover:bg-laya-orange/25 disabled:opacity-50"
						onclick={reopen}
						disabled={reopening}
					>
						{reopening ? 'Reopening...' : card.status === 'archived' ? 'Unarchive' : card.status === 'failed' ? 'Retry' : 'Reopen'}
					</button>
					{#if card.status !== 'archived'}
						<button
							class="flex-1 rounded-md bg-surface-700/30 px-2 py-1.5 text-laya-secondary font-medium text-surface-500 transition-colors hover:bg-surface-700 disabled:opacity-50"
							onclick={archive}
							disabled={archiving}
						>
							{archiving ? '...' : 'Archive'}
						</button>
					{/if}
				</div>
			{:else}
				<div class="flex gap-2">
					<button
						class="flex-1 rounded-md bg-surface-700/30 px-2 py-1.5 text-laya-secondary font-medium text-surface-500 transition-colors hover:bg-surface-700 disabled:opacity-50"
						onclick={archive}
						disabled={archiving}
					>
						{archiving ? '...' : 'Archive'}
					</button>
				</div>
			{/if}
		</div>
	</div>
</div>

{#if showDeleteConfirm}
	<div
		class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
		role="dialog"
		aria-label="Confirm delete"
		tabindex="-1"
		onclick={(e) => { if (e.target === e.currentTarget) showDeleteConfirm = false; }}
		onkeydown={(e) => { if (e.key === 'Escape') showDeleteConfirm = false; }}
	>
		<div class="mx-4 w-full max-w-sm rounded-xl border border-red-800/40 bg-surface-800 p-5 shadow-2xl">
			<div class="mb-3 flex items-start gap-3">
				<div class="mt-0.5 rounded-full bg-red-950/60 p-1.5">
					<svg class="h-4 w-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
					</svg>
				</div>
				<div>
					<h4 class="text-laya-base font-semibold text-surface-50">Delete card permanently?</h4>
					<p class="mt-1 text-laya-secondary leading-relaxed text-surface-400">
						All details, intelligence, workspace sessions, and related events for this card will be
						<span class="font-medium text-red-400">permanently removed</span>. This cannot be undone.
					</p>
				</div>
			</div>
			<div class="flex justify-end gap-2">
				<button
					class="rounded-md px-3 py-1.5 text-laya-secondary text-surface-400 transition-colors hover:text-surface-200 disabled:opacity-50"
					onclick={() => (showDeleteConfirm = false)}
					disabled={deleting}
				>
					Cancel
				</button>
				<button
					class="rounded-md bg-red-700 px-3 py-1.5 text-laya-secondary font-medium text-red-50 transition-colors hover:bg-red-600 disabled:opacity-50"
					onclick={deleteCard}
					disabled={deleting}
				>
					{deleting ? 'Deleting...' : 'Delete permanently'}
				</button>
			</div>
		</div>
	</div>
{/if}

{#if moveMenuOpen}
	<div
		bind:this={moveMenuEl}
		use:portal
		class="fixed z-[100] w-48 rounded-lg border p-1 {$glassTheme ? 'glass-menu' : 'border-surface-600 bg-surface-900 shadow-xl shadow-black/50'}"
		style="top: {moveMenuPos.top}px; right: {moveMenuPos.right}px; transform: translateY(-100%);"
		role="menu"
	>
		<div class="px-2.5 py-1 text-laya-micro font-medium uppercase tracking-wide text-surface-500">Move to space</div>
		{#each otherSpaces as space (space.space_id)}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
				role="menuitem"
				onclick={() => pickMoveSpace(space.space_id, space.name)}
			>
				<span class="inline-block h-1.5 w-1.5 shrink-0 rounded-full" style="background-color: {space.color}"></span>
				<span class="truncate">{space.name}</span>
			</button>
		{/each}
		{#if otherSpaces.length === 0}
			<div class="px-2.5 py-1.5 text-laya-secondary text-surface-500">No other spaces</div>
		{/if}
	</div>
{/if}

{#if moveConfirm}
	<div
		class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
		role="dialog"
		aria-label="Confirm move to space"
		tabindex="-1"
		onclick={(e) => { if (e.target === e.currentTarget) moveConfirm = null; }}
		onkeydown={(e) => { if (e.key === 'Escape') moveConfirm = null; }}
	>
		<div class="mx-4 w-full max-w-md rounded-xl border border-surface-700 bg-surface-800 p-5 shadow-2xl">
			<div class="mb-3 flex items-start gap-3">
				<div class="mt-0.5 rounded-full bg-laya-orange/15 p-1.5">
					<svg class="h-4 w-4 text-laya-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 13h6m0 0l-2-2m2 2l-2 2" /></svg>
				</div>
				<div>
					<h4 class="text-laya-base font-semibold text-surface-50">Move to “{moveConfirm.space_name}”?</h4>
					<p class="mt-1 text-laya-secondary leading-relaxed text-surface-400">{moveConfirm.warning}</p>
				</div>
			</div>
			<div class="flex justify-end gap-2">
				<button
					class="rounded-md px-3 py-1.5 text-laya-secondary text-surface-400 transition-colors hover:text-surface-200 disabled:opacity-50"
					onclick={() => (moveConfirm = null)}
					disabled={moving}
				>
					Cancel
				</button>
				<button
					class="rounded-md bg-laya-orange/20 px-3 py-1.5 text-laya-secondary font-medium text-laya-orange transition-colors hover:bg-laya-orange/30 disabled:opacity-50"
					onclick={confirmMove}
					disabled={moving}
				>
					{moving ? 'Moving...' : 'Move'}
				</button>
			</div>
		</div>
	</div>
{/if}

{#if showClassificationDialog}
	<ClassificationDialog
		{card}
		onclose={() => (showClassificationDialog = false)}
	/>
{/if}

{#if showOriginalModal}
	<OriginalContentModal
		cardId={card.card_id}
		onclose={() => (showOriginalModal = false)}
	/>
{/if}

{#if fixedTooltip}
	<div
		use:portal
		class="pointer-events-none fixed z-[100] -translate-x-1/2 whitespace-nowrap rounded-md border border-transparent glass-tooltip px-2 py-1 text-laya-micro font-medium"
		style="top: {fixedTooltip.top}px; left: {fixedTooltip.left}px;"
	>
		{fixedTooltip.text}
	</div>
{/if}

{#if overflowMenuOpen}
	<div
		bind:this={overflowMenuEl}
		use:portal
		class="fixed z-[100] w-44 rounded-lg border p-1 {$glassTheme ? 'glass-menu' : 'border-surface-600 bg-surface-900 shadow-xl shadow-black/50'}"
		style="top: {overflowMenuPos.top}px; right: {overflowMenuPos.right}px; transform: translateY(-100%);"
		role="menu"
	>
		{#if onlink}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
				role="menuitem"
				onclick={() => { overflowMenuOpen = false; onlink(card); }}
			>
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
				Link to...
			</button>
		{/if}
		{#if hasRelated}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-red-400 disabled:opacity-50"
				role="menuitem"
				disabled={unlinkingCard}
				onclick={unlinkCard}
			>
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /><line x1="4" y1="4" x2="20" y2="20" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
				{unlinkingCard ? 'Unlinking...' : 'Unlink'}
			</button>
		{/if}
		{#if card.status === 'archived'}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-red-400 disabled:opacity-50"
				role="menuitem"
				disabled={deleting}
				onclick={() => { overflowMenuOpen = false; showDeleteConfirm = true; }}
			>
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
				Delete
			</button>
		{/if}
		{#if egressContext && egressContext.actions.length > 0}
			<div class="my-1 border-t {$glassTheme ? 'border-surface-700/40' : 'border-surface-600'}"></div>
			{#each egressContext.actions as action (action.action_type)}
				<button
					class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
					role="menuitem"
					onclick={() => openPlatformAction(action)}
				>
					<svg class="h-3.5 w-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
					<span class="truncate">{action.label}</span>
					{#if action.impact === 'high'}
						<span class="ml-auto text-laya-micro font-bold text-amber-500/70">!</span>
					{/if}
				</button>
			{/each}
			{#if !egressContext.connected}
				<p class="px-2.5 py-1 text-laya-micro text-surface-500 italic">
					Connect {egressContext.platform} to use
				</p>
			{/if}
		{:else if egressLoading}
			<div class="my-1 border-t {$glassTheme ? 'border-surface-700/40' : 'border-surface-600'}"></div>
			<div class="flex items-center gap-2 px-2.5 py-1.5 text-laya-micro text-surface-500">
				<svg class="h-3 w-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" /><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
				Loading actions
			</div>
		{/if}
	</div>
{/if}

{#if headerMenuOpen}
	<div
		bind:this={headerMenuEl}
		use:portal
		class="fixed z-[100] w-44 rounded-lg border p-1 {$glassTheme ? 'glass-menu' : 'border-surface-600 bg-surface-900 shadow-xl shadow-black/50'}"
		style="top: {headerMenuPos.top}px; right: {headerMenuPos.right}px;"
		role="menu"
	>
		{#if ongotocard}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
				role="menuitem"
				onclick={() => { headerMenuOpen = false; ongotocard?.(card); }}
			>
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5" /></svg>
				Go to card
			</button>
		{/if}
		<button
			class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary transition-colors hover:bg-surface-700 {copied ? 'text-green-400' : 'text-surface-300 hover:text-surface-200'}"
			role="menuitem"
			onclick={copyId}
		>
			{#if copied}
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
				Copied!
			{:else}
				<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
				Copy card ID
			{/if}
		</button>
		<button
			class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
			role="menuitem"
			onclick={() => { headerMenuOpen = false; showOriginalModal = true; }}
		>
			<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
			Show original content
		</button>
		<button
			class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary text-surface-300 transition-colors hover:bg-surface-700 hover:text-surface-200"
			role="menuitem"
			onclick={() => { headerMenuOpen = false; chatAbout(); }}
		>
			<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
			Chat about card
		</button>
		<button
			class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary transition-colors hover:bg-surface-700 disabled:opacity-50 {card.bookmarked_at ? 'text-laya-orange' : 'text-surface-300 hover:text-laya-orange'}"
			role="menuitem"
			disabled={bookmarking}
			onclick={toggleBookmark}
		>
			<svg class="h-3.5 w-3.5" fill={card.bookmarked_at ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
			{card.bookmarked_at ? 'Remove bookmark' : 'Bookmark'}
		</button>
		<!-- Reprocess: re-run the pipeline on this card's event (recovery for a
		     card whose LLM output came back garbled). Disabled while the card is
		     already in flight. -->
		<div class="my-1 border-t border-surface-700/60"></div>
		<button
			class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-laya-secondary transition-colors hover:bg-surface-700 disabled:opacity-40 disabled:hover:bg-transparent {reprocessing ? 'text-laya-orange' : 'text-surface-300 hover:text-surface-200'}"
			role="menuitem"
			disabled={reprocessing || card.status === 'pending' || card.status === 'agent_running'}
			onclick={reprocess}
		>
			<svg class="h-3.5 w-3.5 {reprocessing ? 'animate-spin' : ''}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
			{reprocessing ? 'Reprocessing…' : 'Reprocess'}
		</button>
	</div>
{/if}

{#if showTagDropdown && filteredTags.length > 0}
	<div
		use:portal
		class="fixed z-[100] w-48 rounded-lg border p-1 {$glassTheme ? 'glass-menu' : 'border-surface-600 bg-surface-900 shadow-xl shadow-black/50'}"
		style="top: {tagDropdownPos.top}px; left: {tagDropdownPos.left}px;"
		role="listbox"
	>
		{#each filteredTags as tag}
			<button
				class="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-xs text-surface-300 transition-colors hover:bg-surface-700/50 cursor-pointer"
				role="option"
				aria-selected={false}
				onmousedown={(e) => { e.preventDefault(); addTag(tag.tag_id); }}
			>
				{#if tag.color}
					<span class="h-2 w-2 rounded-full shrink-0" style="background-color: {tag.color}"></span>
				{/if}
				{tag.name}
			</button>
		{/each}
	</div>
{/if}
