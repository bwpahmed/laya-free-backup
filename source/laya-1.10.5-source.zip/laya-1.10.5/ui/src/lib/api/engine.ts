// Copyright 2026 Aayush Chawla
// SPDX-License-Identifier: Apache-2.0

import type {
	TeamConfig,
	RulesConfig,
	Settings,
	ReposConfig,
	ActionCard,
	SourceEvent,
	CardsListResponse,
	GroupedCardsResponse,
	ExecuteActionResponse,
	WorkspaceResponse,
	DashboardResponse,
	ChatMessage,
	ChatResponse,
	Conversation,
	AuditLogResponse,
	N8nTestResult,
	PlatformsResponse,
	ConnectionsResponse,
	CreateConnectionRequest,
	CreateConnectionResponse,
	ConnectionTestResult,
	N8nBootstrapResponse,
	DaySummaryResponse,
	SpacesResponse,
	SourcesResponse,
	AvailableWorkflowsResponse,
	Space,
	Source,
	SpaceApiKeysResponse,
	SpaceReposResponse,
	AvailableModelsResponse,
	AgentBackendsResponse,
	CustomProvider,
	CustomProviderTestResult,
	DiscoveredModel,
	BudgetConfig,
	MonthlyCostEntry,
	AgentBudgetStatus,
	AgentBudgetConfigInput,
	EgressExecuteRequest,
	EgressExecuteResponse,
	EgressPreviewResponse,
	EgressCapabilitiesResponse,
	ComposePlatformsResponse,
	CardEgressContext,
	EgressConnectionsResponse,
	EgressConnectRequest,
	EgressConnectResponse,
	EgressAiAssistRequest,
	EgressAiAssistResponse,
	EmailProviderDetection,
	OAuthStartResponse,
	OmniSnapshot,
	OmniHistoryResponse,
	OmniTimelineResponse,
	OmniPinsResponse,
	OmniPin,
	OmniChangesResponse,
	OmniVolumeResponse,
	OmniItemResponse,
	OmniResynthesisStatus,
	DeadEventsResponse,
	RetryDeadEventsResponse,
	FilteredEventsResponse,
	ExportEnvelope,
	DayEventsResponse,
	EventCountsResponse,
	AuditFailureSummary,
	IngestionErrorsResponse,
	ClearIngestionErrorsResponse,
	Tag,
	TagAssignment,
	McpConfig,
	McpConfigUpdate,
	McpToken,
	ThroughputResponse
} from './types';

import { getEngineToken, getEngineUrl } from '$lib/config';

const ENGINE_URL = getEngineUrl();

// Trace runs (initial + rerun) execute a multi-stage discovery/LLM pipeline that
// can take several minutes on a local model — observed up to ~7m40s. A single
// shared constant applied to BOTH runTrace and rerunTrace: they used to carry
// separate per-call-site literals (240s vs the inherited 30s default), and that
// drift is exactly what made every rerun abort client-side at 30s.
const TRACE_TIMEOUT_MS = 600_000;

export async function engineFetch(path: string, options?: RequestInit): Promise<Response> {
	const signal = options?.signal ?? AbortSignal.timeout(30_000);
	const headers = new Headers(options?.headers);
	if (!headers.has('Content-Type') && !(options?.body instanceof FormData)) {
		headers.set('Content-Type', 'application/json');
	}
	const token = getEngineToken();
	if (token && !headers.has('Authorization')) {
		headers.set('Authorization', `Bearer ${token}`);
	}
	return fetch(`${ENGINE_URL}${path}`, {
		...options,
		headers,
		signal,
	});
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
	const resp = await engineFetch(path, options);
	if (!resp.ok) {
		let detail: string | undefined;
		try {
			const body = await resp.json();
			detail = typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail);
		} catch {
			// no parseable body
		}
		throw new Error(detail || `Engine API error: ${resp.status} ${resp.statusText}`);
	}
	return resp.json();
}

export const engineApi = {
	// Team
	getTeam: () => request<TeamConfig>('/team'),
	updateTeam: (team: TeamConfig) =>
		request<{ status: string }>('/team', {
			method: 'PUT',
			body: JSON.stringify(team)
		}),

	// Rules
	getRules: () => request<RulesConfig>('/rules'),
	updateRules: (rules: RulesConfig) =>
		request<{ status: string }>('/rules', {
			method: 'PUT',
			body: JSON.stringify(rules)
		}),

	// Processing Rules
	listProcessingRules: (spaceId?: string) =>
		request<{ rules: import('./types').ProcessingRule[] }>(
			`/processing-rules${spaceId ? `?space_id=${spaceId}` : ''}`
		),
	createProcessingRule: (data: {
		name: string; description?: string; space_id?: string; enabled?: boolean;
		condition: import('./types').ProcessingCondition; actions: import('./types').ProcessingRuleAction[];
		rate_limit?: number; cooldown_secs?: number; max_daily?: number;
	}) =>
		request<import('./types').ProcessingRule>('/processing-rules', {
			method: 'POST', body: JSON.stringify(data)
		}),
	updateProcessingRule: (id: number, data: Record<string, unknown>) =>
		request<import('./types').ProcessingRule>(`/processing-rules/${id}`, {
			method: 'PUT', body: JSON.stringify(data)
		}),
	deleteProcessingRule: (id: number) =>
		request<{ status: string }>(`/processing-rules/${id}`, { method: 'DELETE' }),
	toggleProcessingRule: (id: number) =>
		request<{ id: number; enabled: boolean }>(`/processing-rules/${id}/toggle`, { method: 'PUT' }),
	reorderProcessingRules: (order: number[]) =>
		request<{ status: string }>('/processing-rules/reorder', {
			method: 'PUT', body: JSON.stringify({ order })
		}),
	previewProcessingRuleMatches: (condition: import('./types').ProcessingCondition) =>
		request<{ match_count: number; sample_cards: Array<{ card_id: string; header: string; priority: string; persona: string; status: string }>; period: string }>(
			'/processing-rules/preview-matches',
			{ method: 'POST', body: JSON.stringify({ condition }) }
		),
	getProcessingRuleHistory: (id: number, limit?: number) =>
		request<{ rule_id: number; firings: import('./types').ProcessingRuleFiring[] }>(
			`/processing-rules/${id}/history${limit ? `?limit=${limit}` : ''}`
		),
	getProcessingRuleFirings: (params?: {
		rule_id?: number;
		outcome?: 'success' | 'error' | 'skipped';
		search?: string;
		limit?: number;
		offset?: number;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.rule_id !== undefined) searchParams.set('rule_id', String(params.rule_id));
		if (params?.outcome) searchParams.set('outcome', params.outcome);
		if (params?.search) searchParams.set('search', params.search);
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<import('./types').ProcessingRuleFiringResponse>(
			`/processing-rules/firings${qs ? '?' + qs : ''}`
		);
	},
	getProcessingRuleFieldOptions: () =>
		request<Record<string, string[]>>('/processing-rules/field-options'),
	getMetadataFields: (platform: string) =>
		request<{ keys: Record<string, string[]> }>(`/processing-rules/metadata-fields?platform=${platform}`),
	getProcessingRulesSettings: () =>
		request<{ auto_disable_threshold: number }>('/processing-rules/settings'),
	updateProcessingRulesSettings: (body: { auto_disable_threshold: number }) =>
		request<{ auto_disable_threshold: number }>('/processing-rules/settings', {
			method: 'PUT',
			body: JSON.stringify(body),
		}),

	// Repos
	getRepos: () => request<ReposConfig>('/repos'),
	updateRepos: (repos: ReposConfig) =>
		request<{ status: string }>('/repos', {
			method: 'PUT',
			body: JSON.stringify(repos)
		}),

	// Settings
	getSettings: () => request<Settings>('/settings'),
	updateSettings: (settings: Partial<Settings>) =>
		request<{ status: string }>('/settings', {
			method: 'PUT',
			body: JSON.stringify(settings)
		}),
	getSetupStatus: () => request<{ setup_complete: boolean }>('/settings/setup-status'),
	exportDiagnostics: async (): Promise<Blob> => {
		const resp = await engineFetch('/diagnostics/export');
		if (!resp.ok) throw new Error(`Export failed: ${resp.status}`);
		return resp.blob();
	},

	// Prompt overrides loaded from ~/.laya/prompts/
	getPrompts: () =>
		request<{ prompts: { key: string; file: string; overridden: boolean }[] }>('/prompts'),
	reloadPrompts: () =>
		request<{ status: string; overridden_keys: string[] }>('/prompts/reload', {
			method: 'POST'
		}),

	detectAgentPaths: () =>
		request<{ agent_paths: Record<string, string> }>('/settings/detect-agents'),

	// Installed CLI agents usable as the inference backend (availability + capability tier)
	getAgentBackends: () =>
		request<AgentBackendsResponse>('/settings/agent-backends'),

	// API Keys
	setApiKey: (provider: string, apiKey: string) =>
		request<{ status: string; provider: string }>('/settings/api-key', {
			method: 'PUT',
			body: JSON.stringify({ provider, api_key: apiKey })
		}),
	deleteApiKey: (provider: string) =>
		request<{ status: string; provider: string }>(`/settings/api-key/${provider}`, {
			method: 'DELETE'
		}),

	// Available models (dynamic, grouped by provider)
	getAvailableModels: (refresh?: boolean) =>
		request<AvailableModelsResponse>(
			`/settings/available-models${refresh ? '?refresh=true' : ''}`
		),

	// Cards
	getCards: (params?: {
		status?: string;
		priority?: string;
		limit?: number;
		offset?: number;
		sort?: string;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.status) searchParams.set('status', params.status);
		if (params?.priority) searchParams.set('priority', params.priority);
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		if (params?.sort) searchParams.set('sort', params.sort);
		const qs = searchParams.toString();
		return request<CardsListResponse>(`/cards${qs ? '?' + qs : ''}`);
	},
	getCard: (cardId: string) => request<ActionCard>(`/cards/${cardId}`),
	getCardSourceEvent: (cardId: string) =>
		request<SourceEvent>(`/cards/${encodeURIComponent(cardId)}/source-event`),
	getGroupedCards: (params?: {
		status?: string;
		priority?: string;
		sort?: string;
		sort_asc?: boolean;
		show_archived?: boolean;
		date?: string;
		space_id?: string;
		bookmarked?: boolean;
		has_workspace?: boolean;
		unread_only?: boolean;
		related_entity_ids?: string;
		search?: string;
		tags?: string;
		limit?: number;
		offset?: number;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.status) searchParams.set('status', params.status);
		if (params?.priority) searchParams.set('priority', params.priority);
		if (params?.sort) searchParams.set('sort', params.sort);
		if (params?.sort_asc) searchParams.set('sort_asc', 'true');
		if (params?.show_archived) searchParams.set('show_archived', 'true');
		if (params?.date) searchParams.set('date', params.date);
		if (params?.space_id) searchParams.set('space_id', params.space_id);
		if (params?.bookmarked) searchParams.set('bookmarked', 'true');
		if (params?.has_workspace) searchParams.set('has_workspace', 'true');
		if (params?.unread_only) searchParams.set('unread_only', 'true');
		if (params?.related_entity_ids) searchParams.set('related_entity_ids', params.related_entity_ids);
		if (params?.search) searchParams.set('search', params.search);
		if (params?.tags) searchParams.set('tags', params.tags);
		if (params?.limit !== undefined) searchParams.set('limit', String(params.limit));
		if (params?.offset !== undefined) searchParams.set('offset', String(params.offset));
		searchParams.set('tz', Intl.DateTimeFormat().resolvedOptions().timeZone);
		const qs = searchParams.toString();
		return request<GroupedCardsResponse>(`/cards/grouped${qs ? '?' + qs : ''}`);
	},
	dismissGroup: (entityId: string) =>
		request<{ dismissed: number; entity_id: string }>(
			`/cards/group/${encodeURIComponent(entityId)}/dismiss-all`,
			{ method: 'POST' }
		),
	markCardDone: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/done`, {
			method: 'POST'
		}),
	uploadAgentFile: (file: File) => {
		const formData = new FormData();
		formData.append('file', file);
		return request<{ path: string; filename: string; content_type?: string }>('/upload-agent-file', {
			method: 'POST',
			body: formData
		});
	},
	uploadAgentFilePath: (path: string) =>
		request<{ path: string; filename: string; content_type?: string }>('/upload-agent-file-path', {
			method: 'POST',
			body: JSON.stringify({ path })
		}),
	deleteAgentStagingFile: (path: string) =>
		request<{ status: string }>('/delete-agent-staging-file', {
			method: 'POST',
			body: JSON.stringify({ path })
		}),
	runAgent: (data: {
		prompt: string;
		directory?: string;
		add_dirs?: string[];
		agent_type?: string;
		mode?: string;
		space_id?: string;
		files?: string[];
	}) =>
		request<{ status: string; card_id: string }>('/cards/run-agent', {
			method: 'POST',
			body: JSON.stringify(data)
		}),
	runEntityAgent: (entityId: string, data?: { prompt?: string }) =>
		request<{ status: string; session_id: string; card_id: string }>(
			`/entity/${encodeURIComponent(entityId)}/run-agent`,
			{ method: 'POST', body: JSON.stringify(data ?? {}) }
		),
	dismissCard: (cardId: string, reason?: string, feedbackType?: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/dismiss`, {
			method: 'POST',
			body: JSON.stringify({ reason: reason ?? null, feedback_type: feedbackType ?? null })
		}),
	archiveCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/archive`, {
			method: 'POST'
		}),
	reopenCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/reopen`, {
			method: 'POST'
		}),
	reprocessCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/reprocess`, {
			method: 'POST'
		}),
	// Move a card (and its whole group) to another space. dry_run=true returns the
	// scope + warning without mutating; the real move returns what was moved.
	moveCard: (cardId: string, data: { space_id: string; dry_run?: boolean }) =>
		request<{
			// dry-run preview fields
			scope?: 'context' | 'entity' | 'standalone';
			affected_card_ids?: string[];
			card_count?: number;
			entity_ids?: string[];
			context_id?: string | null;
			space_name?: string;
			warning?: string;
			// actual-move fields
			status?: string;
			moved_card_ids?: string[];
			count?: number;
			space_id: string;
		}>(`/cards/${cardId}/move`, {
			method: 'POST',
			body: JSON.stringify(data)
		}),
	// Related cards
	getRelatedCards: (cardId: string) =>
		request<{ card_id: string; related_cards: Array<{ card_id: string; header: string; entity_id: string; status: string; context_id: string; context_label: string; confidence: number; link_method: string }>; total_related_cards: number }>(`/cards/${cardId}/related`),
	unlinkRelatedCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/unlink-related`, { method: 'POST' }),
	// Context group management
	getContextGroup: (contextId: string) =>
		request<{ context_id: string; label: string; user_confirmed: boolean; user_split: boolean; members: Array<{ entity_id: string; confidence: number; link_method: string }>; cards: Array<{ card_id: string; header: string; entity_id: string; status: string }> }>(`/cards/groups/${contextId}`),
	unlinkContextGroup: (contextId: string) =>
		request<{ status: string; context_id: string }>(`/cards/groups/${contextId}/unlink`, {
			method: 'POST'
		}),
	mergeCards: (cardIds: string[]) =>
		request<{ status: string; context_id: string; card_count: number }>('/cards/groups/merge', {
			method: 'POST',
			body: JSON.stringify({ card_ids: cardIds })
		}),
	// Group summaries
	getGroupSummary: (entityId: string) =>
		request<import('./types').GroupSummary>(`/cards/groups/${encodeURIComponent(entityId)}/summary`),
	regenerateGroupSummary: (entityId: string) =>
		request<import('./types').GroupSummary>(`/cards/groups/${encodeURIComponent(entityId)}/summary/regenerate`, {
			method: 'POST'
		}),
	deleteCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}`, {
			method: 'DELETE'
		}),
	bookmarkCard: (cardId: string) =>
		request<{ status: string; card_id: string; bookmarked_at: string }>(`/cards/${cardId}/bookmark`, {
			method: 'POST'
		}),
	unbookmarkCard: (cardId: string) =>
		request<{ status: string; card_id: string }>(`/cards/${cardId}/unbookmark`, {
			method: 'POST'
		}),
	markCardRead: (cardId: string) =>
		request<{ status: string; card_id: string; read_at: string }>(`/cards/${cardId}/read`, {
			method: 'POST'
		}),
	markGroupRead: (entityId: string) =>
		request<{ status: string; entity_id: string; marked: number }>(
			`/cards/group/${encodeURIComponent(entityId)}/read-all`,
			{ method: 'POST' }
		),
	markAllRead: (params?: { date?: string; space_id?: string }) => {
		const searchParams = new URLSearchParams();
		if (params?.date) searchParams.set('date', params.date);
		if (params?.space_id) searchParams.set('space_id', params.space_id);
		searchParams.set('tz', Intl.DateTimeFormat().resolvedOptions().timeZone);
		const qs = searchParams.toString();
		return request<{ status: string; marked: number }>(`/cards/read-all${qs ? '?' + qs : ''}`, {
			method: 'POST'
		});
	},
	updateCardClassification: (cardId: string, body: import('./types').UpdateClassificationRequest) =>
		request<{ status: string; card_id: string; corrections: number }>(`/cards/${cardId}/classification`, {
			method: 'PATCH',
			body: JSON.stringify(body)
		}),

	// Classification rules
	getClassificationRules: (spaceId?: string) => {
		const qs = spaceId ? `?space_id=${spaceId}` : '';
		return request<import('./types').ClassificationRule[]>(`/classification/rules${qs}`);
	},
	createClassificationRule: (body: { rule_text: string; field?: string | null; space_id?: string | null }) =>
		request<{ id: number; status: string }>('/classification/rules', {
			method: 'POST',
			body: JSON.stringify(body)
		}),
	updateClassificationRule: (ruleId: number, body: { rule_text?: string; field?: string | null; active?: boolean }) =>
		request<{ id: number; status: string }>(`/classification/rules/${ruleId}`, {
			method: 'PUT',
			body: JSON.stringify(body)
		}),
	deleteClassificationRule: (ruleId: number) =>
		request<{ id: number; status: string }>(`/classification/rules/${ruleId}`, {
			method: 'DELETE'
		}),

	// Context rules (learned context-grouping rules + manual)
	getContextRules: (params?: {
		space_id?: string;
		source?: 'manual' | 'learned';
		active?: boolean;
		limit?: number;
		offset?: number;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.space_id) searchParams.set('space_id', params.space_id);
		if (params?.source) searchParams.set('source', params.source);
		if (params?.active !== undefined) searchParams.set('active', String(params.active));
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<import('./types').ContextRuleListResponse>(`/context-rules${qs ? '?' + qs : ''}`);
	},
	createContextRule: (body: { rule_text: string; space_id?: string | null }) =>
		request<{ id: number; status: string }>('/context-rules', {
			method: 'POST',
			body: JSON.stringify(body)
		}),
	updateContextRule: (ruleId: number, body: { rule_text?: string; active?: boolean }) =>
		request<{ id: number; status: string }>(`/context-rules/${ruleId}`, {
			method: 'PUT',
			body: JSON.stringify(body)
		}),
	deleteContextRule: (ruleId: number) =>
		request<{ id: number; status: string }>(`/context-rules/${ruleId}`, {
			method: 'DELETE'
		}),

	// Summary
	getDaySummary: (date?: string) => {
		const params = new URLSearchParams();
		if (date) params.set('date', date);
		params.set('tz', Intl.DateTimeFormat().resolvedOptions().timeZone);
		return request<DaySummaryResponse>(`/summary?${params.toString()}`);
	},

	// Actions
	executeAction: (cardId: string, actionId: string, modifications?: Record<string, unknown>) =>
		request<ExecuteActionResponse>('/actions/execute', {
			method: 'POST',
			body: JSON.stringify({
				card_id: cardId,
				action_id: actionId,
				modifications: modifications ?? null
			})
		}),

	updateActionPayload: (cardId: string, actionId: string, payload: Record<string, string>) =>
		request<{ status: string }>(`/cards/${cardId}/action-payload`, {
			method: 'POST',
			body: JSON.stringify({ action_id: actionId, payload })
		}),

	polishActionPayload: (cardId: string, actionId: string) =>
		request<{ status: string; card_id: string; action_id: string }>(
			`/cards/${cardId}/action-payload/polish`,
			{
				method: 'POST',
				body: JSON.stringify({ action_id: actionId })
			}
		),

	// Workspace
	getWorkspace: (cardId: string) => request<WorkspaceResponse>(`/cards/${cardId}/workspace`),

	answerAgentQuestion: (sessionId: string, answers: Array<{ header?: string; selected: string }>, addDirs?: string[], mode?: string) =>
		request<{ status: string; session_id: string }>(`/workspace/${sessionId}/answer`, {
			method: 'POST',
			body: JSON.stringify({ answers, add_dirs: addDirs?.length ? addDirs : undefined, mode: mode || undefined })
		}),

	resumeSession: (sessionId: string, prompt: string, addDirs?: string[], mode?: string) =>
		request<{ status: string; session_id: string }>(`/workspace/${sessionId}/resume`, {
			method: 'POST',
			body: JSON.stringify({ prompt, add_dirs: addDirs?.length ? addDirs : undefined, mode: mode || undefined })
		}),

	dismissQuestions: (sessionId: string) =>
		request<{ status: string; session_id: string }>(`/workspace/${sessionId}/dismiss-questions`, {
			method: 'POST'
		}),

	// Research file browsing
	listResearchFiles: (cardId: string) =>
		request<{ card_id: string; files: Array<{ name: string; path: string; size: number; modified: number }> }>(
			`/workspace/research-files/${cardId}`
		),
	readResearchFile: (cardId: string, filePath: string) =>
		request<{ path: string; name: string; content: string }>(
			`/workspace/research-files/${cardId}/read?path=${encodeURIComponent(filePath)}`
		),

	// Dashboard
	getDashboard: (days?: number) => {
		const qs = days ? `?days=${days}` : '';
		return request<DashboardResponse>(`/dashboard${qs}`);
	},

	getThroughput: (minutes?: number) => {
		const qs = minutes ? `?minutes=${minutes}` : '';
		return request<ThroughputResponse>(`/dashboard/throughput${qs}`);
	},

	// Chat
	getChatHistory: (limit?: number, conversationId?: string) => {
		const params = new URLSearchParams();
		if (limit) params.set('limit', String(limit));
		if (conversationId) params.set('conversation_id', conversationId);
		const qs = params.toString();
		return request<ChatMessage[]>(`/chat/history${qs ? '?' + qs : ''}`);
	},
	sendChat: (message: string, conversationId?: string, cardContext?: string, cardIds?: string[]) =>
		request<ChatResponse>('/chat', {
			method: 'POST',
			body: JSON.stringify({
				message,
				conversation_id: conversationId ?? null,
				...(cardContext ? { card_context: cardContext } : {}),
				...(cardIds && cardIds.length > 0 ? { card_ids: cardIds } : {})
			})
		}),

	// Chat Conversations
	getConversations: (limit?: number) => {
		const qs = limit ? `?limit=${limit}` : '';
		return request<Conversation[]>(`/chat/conversations${qs}`);
	},
	createConversation: (title?: string, spaceId?: string) =>
		request<Conversation>('/chat/conversations', {
			method: 'POST',
			body: JSON.stringify({ title: title ?? 'New Chat', space_id: spaceId ?? null })
		}),
	getConversationMessages: (conversationId: string, limit?: number) => {
		const qs = limit ? `?limit=${limit}` : '';
		return request<ChatMessage[]>(`/chat/conversations/${conversationId}/messages${qs}`);
	},
	getConversationByCards: (cardIds: string[]) => {
		if (!cardIds || cardIds.length === 0) return Promise.resolve(null);
		const params = new URLSearchParams();
		for (const id of cardIds) params.append('card_ids', id);
		return request<Conversation | null>(`/chat/conversations/by-cards?${params.toString()}`);
	},
	deleteConversation: (conversationId: string) =>
		request<{ status: string; conversation_id: string }>(`/chat/conversations/${conversationId}`, {
			method: 'DELETE'
		}),
	renameConversation: (conversationId: string, title: string) =>
		request<{ status: string; conversation_id: string }>(`/chat/conversations/${conversationId}`, {
			method: 'PUT',
			body: JSON.stringify({ title })
		}),

	// n8n
	testN8nConnection: (baseUrl?: string, webhookPath?: string) =>
		request<N8nTestResult>('/settings/n8n/test', {
			method: 'POST',
			body: JSON.stringify({
				...(baseUrl ? { base_url: baseUrl } : {}),
				...(webhookPath ? { webhook_path: webhookPath } : {})
			})
		}),

	// Connections (n8n credentials)
	getPlatforms: () => request<PlatformsResponse>('/connections/platforms'),

	getConnections: () => request<ConnectionsResponse>('/connections'),

	createConnection: (req: CreateConnectionRequest) =>
		request<CreateConnectionResponse>('/connections', {
			method: 'POST',
			body: JSON.stringify(req)
		}),

	deleteConnection: (id: string) =>
		request<{ status: string; id: string }>(`/connections/${id}`, {
			method: 'DELETE'
		}),

	testN8nApi: () =>
		request<ConnectionTestResult>('/connections/test', {
			method: 'POST'
		}),

	bootstrapN8n: () =>
		request<N8nBootstrapResponse>('/settings/n8n/bootstrap', {
			method: 'POST'
		}),

	// Spaces
	getSpaces: () => request<SpacesResponse>('/spaces'),

	createSpace: (space: { name: string; description?: string; icon?: string; color?: string; router_model?: string; stager_model?: string; chat_model?: string; trace_model?: string; omni_model?: string; coding_agent?: string }) =>
		request<Space>('/spaces', {
			method: 'POST',
			body: JSON.stringify(space)
		}),

	updateSpace: (spaceId: string, updates: Partial<{ name: string; description: string; icon: string; color: string; router_model: string | null; stager_model: string | null; chat_model: string | null; trace_model: string | null; omni_model: string | null; coding_agent: string | null }>) =>
		request<{ status: string; space_id: string }>(`/spaces/${spaceId}`, {
			method: 'PUT',
			body: JSON.stringify(updates)
		}),

	deleteSpace: (spaceId: string) =>
		request<{ status: string; space_id: string }>(`/spaces/${spaceId}`, {
			method: 'DELETE'
		}),

	// Space API Keys
	getSpaceApiKeys: (spaceId: string) =>
		request<SpaceApiKeysResponse>(`/spaces/${spaceId}/api-keys`),

	setSpaceApiKey: (spaceId: string, provider: string, apiKey: string) =>
		request<{ status: string; provider: string }>(`/spaces/${spaceId}/api-key`, {
			method: 'PUT',
			body: JSON.stringify({ provider, api_key: apiKey })
		}),

	deleteSpaceApiKey: (spaceId: string, provider: string) =>
		request<{ status: string; provider: string }>(`/spaces/${spaceId}/api-key/${provider}`, {
			method: 'DELETE'
		}),

	// Space Pause / Unpause
	setSpacePaused: (spaceId: string, paused: boolean) =>
		request<{ status: string; space_id: string; workflows_toggled: number; errors: Array<{ workflow_id: string; name: string; error?: string; issues?: string[] }> }>(`/spaces/${spaceId}/paused`, {
			method: 'PUT',
			body: JSON.stringify({ paused })
		}),

	// Space Repos
	getSpaceRepos: (spaceId: string) =>
		request<SpaceReposResponse>(`/spaces/${spaceId}/repos`),

	setSpaceRepos: (spaceId: string, repoNames: string[]) =>
		request<{ status: string; count: number }>(`/spaces/${spaceId}/repos`, {
			method: 'PUT',
			body: JSON.stringify({ repo_names: repoNames })
		}),

	// Sources
	getSources: () => request<SourcesResponse>('/sources'),

	getAvailableWorkflows: () => request<AvailableWorkflowsResponse>('/sources/available-workflows'),

	setWorkflowActive: (workflowId: string, active: boolean) =>
		request<{ status: string; workflow_id: string; active: boolean }>(`/sources/workflows/${workflowId}/active`, {
			method: 'PUT',
			body: JSON.stringify({ active })
		}),

	createSource: (source: { name: string; platform: string; workflow_id: string; space_id?: string; source_type?: string; webhook_path?: string }) =>
		request<Source>('/sources', {
			method: 'POST',
			body: JSON.stringify(source)
		}),

	reassignSource: (sourceId: string, spaceId: string) =>
		request<{ status: string; source_id: string; space_id: string }>(`/sources/${sourceId}/space`, {
			method: 'PUT',
			body: JSON.stringify({ space_id: spaceId })
		}),

	deleteSource: (sourceId: string) =>
		request<{ status: string; source_id: string }>(`/sources/${sourceId}`, {
			method: 'DELETE'
		}),

	bulkAssignSources: (spaceId: string, sourceIds: string[]) =>
		request<{ status: string; updated: number }>(`/spaces/${spaceId}/sources`, {
			method: 'PUT',
			body: JSON.stringify({ source_ids: sourceIds })
		}),

	// Custom Providers (local models)
	getCustomProviders: () =>
		request<{ providers: CustomProvider[] }>('/settings/custom-providers'),

	addCustomProvider: (provider: {
		name: string;
		base_url: string;
		provider_type: string;
		api_key?: string;
		default_timeout?: number;
		capabilities_override?: { supports_tool_calling?: boolean; supports_structured_output?: boolean };
	}) =>
		request<{ status: string; provider: CustomProvider }>('/settings/custom-providers', {
			method: 'POST',
			body: JSON.stringify(provider)
		}),

	updateCustomProvider: (providerId: string, updates: {
		name?: string;
		base_url?: string;
		provider_type?: string;
		api_key?: string;
		default_timeout?: number;
		capabilities_override?: { supports_tool_calling?: boolean; supports_structured_output?: boolean };
	}) =>
		request<{ status: string; provider: CustomProvider }>(`/settings/custom-providers/${providerId}`, {
			method: 'PUT',
			body: JSON.stringify(updates)
		}),

	deleteCustomProvider: (providerId: string) =>
		request<{ status: string; provider_id: string }>(`/settings/custom-providers/${providerId}`, {
			method: 'DELETE'
		}),

	testCustomProvider: (providerId: string) =>
		request<CustomProviderTestResult>(`/settings/custom-providers/${providerId}/test`, {
			method: 'POST'
		}),

	getProviderModels: (providerId: string) =>
		request<{ provider_id: string; provider_name: string; models: DiscoveredModel[] }>(
			`/settings/custom-providers/${providerId}/models`
		),

	// Budget / Cost Control
	getBudget: () => request<BudgetConfig>('/budget'),

	updateBudget: (config: { monthly_limit_usd: number | null; enabled: boolean }) =>
		request<{ status: string; monthly_limit_usd: number | null; enabled: boolean }>('/budget', {
			method: 'PUT',
			body: JSON.stringify(config)
		}),

	getBudgetHistory: (months?: number) =>
		request<{ months: MonthlyCostEntry[] }>(`/budget/history${months ? '?months=' + months : ''}`),

	resumeBudget: () =>
		request<{ status: string; resumed_count: number; errors: Array<{ workflow_id: string; error?: string; issues?: string[] }> }>('/budget/resume', {
			method: 'POST'
		}),

	// Agent inference backend — usage-limit budget (window-based, auto-resume)
	getAgentBudget: () => request<AgentBudgetStatus>('/agent-budget'),

	updateAgentBudget: (config: { enabled: boolean; agents: Record<string, AgentBudgetConfigInput> }) =>
		request<{ status: string } & AgentBudgetStatus>('/agent-budget', {
			method: 'PUT',
			body: JSON.stringify(config)
		}),

	resumeAgentBudget: () =>
		request<{ status: string; resumed_count: number; errors: Array<{ workflow_id: string; error?: string; issues?: string[] }> }>('/agent-budget/resume', {
			method: 'POST'
		}),

	// Trace
	runTrace: (query: string, spaceId?: string, fuzzySearch = false, opts?: {
		enableSemantic?: boolean;
		enableText?: boolean;
		enableLlmFilter?: boolean;
	}) =>
		request<import('./types').TraceResponse>('/trace', {
			method: 'POST',
			signal: AbortSignal.timeout(TRACE_TIMEOUT_MS),
			body: JSON.stringify({
				query,
				space_id: spaceId || null,
				include_archived: true,
				max_results: 200,
				fuzzy_search: fuzzySearch,
				...(opts?.enableSemantic !== undefined && { enable_semantic: opts.enableSemantic }),
				...(opts?.enableText !== undefined && { enable_text: opts.enableText }),
				...(opts?.enableLlmFilter !== undefined && { enable_llm_filter: opts.enableLlmFilter }),
			})
		}),

	getTraces: (limit = 20, offset = 0) =>
		request<import('./types').TraceListItem[]>(`/traces?limit=${limit}&offset=${offset}`),

	cancelTrace: () =>
		request<{ cancelled: string[] }>('/trace/cancel', { method: 'POST' }),

	getTrace: (traceId: string) =>
		request<import('./types').TraceResponse>(`/traces/${traceId}`),

	rerunTrace: (traceId: string) =>
		request<import('./types').TraceResponse>(`/traces/${traceId}/rerun`, {
			method: 'POST',
			signal: AbortSignal.timeout(TRACE_TIMEOUT_MS),
		}),

	deleteTrace: (traceId: string) =>
		request<{ deleted: string }>(`/traces/${traceId}`, { method: 'DELETE' }),

	generateClusterNarrative: (traceId: string, clusterId: string) =>
		request<{ status: string }>(`/traces/${traceId}/clusters/${clusterId}/narrative`, {
			method: 'POST'
		}),

	generateTraceSummary: (traceId: string) =>
		request<{ status: string }>(`/traces/${traceId}/summary`, {
			method: 'POST'
		}),

	removeCluster: (traceId: string, clusterId: string) =>
		request<{ removed: string }>(`/traces/${traceId}/clusters/${clusterId}`, {
			method: 'DELETE'
		}),

	restoreClusters: (traceId: string) =>
		request<{ restored: string }>(`/traces/${traceId}/clusters/restore`, {
			method: 'POST'
		}),

	exportTrace: async (traceId: string): Promise<Blob> => {
		const resp = await engineFetch(`/traces/${traceId}/export`);
		if (!resp.ok) throw new Error(`Export failed: ${resp.status}`);
		return resp.blob();
	},

	// Audit Log
	getAuditLog: (params?: {
		step?: string;
		success?: boolean;
		search?: string;
		limit?: number;
		offset?: number;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.step) searchParams.set('step', params.step);
		if (params?.success !== undefined) searchParams.set('success', String(params.success));
		if (params?.search) searchParams.set('search', params.search);
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<AuditLogResponse>(`/audit-log${qs ? '?' + qs : ''}`);
	},

	// Dead Events
	getDeadEvents: (params?: { limit?: number; offset?: number }) => {
		const searchParams = new URLSearchParams();
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<DeadEventsResponse>(`/events/dead${qs ? '?' + qs : ''}`);
	},

	retryDeadEvents: (eventIds?: string[]) =>
		request<RetryDeadEventsResponse>('/events/dead/retry', {
			method: 'POST',
			body: JSON.stringify(eventIds ? { event_ids: eventIds } : { all: true })
		}),

	// Filtered Events (informational — events dropped by filter rules)
	getFilteredEvents: (params?: { limit?: number; offset?: number }) => {
		const searchParams = new URLSearchParams();
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<FilteredEventsResponse>(`/events/filtered${qs ? '?' + qs : ''}`);
	},

	// Filtered Events export — full JSON, optionally limited to last `days` (0 = all time)
	exportFilteredEvents: (days = 0) =>
		request<ExportEnvelope<Record<string, unknown>>>(
			`/events/filtered/export${days > 0 ? `?days=${days}` : ''}`
		),

	// Audit log export — full JSON honoring current filters + last `days` (0 = all time)
	exportAuditLog: (params: { days?: number; step?: string; success?: boolean; search?: string }) => {
		const searchParams = new URLSearchParams();
		if (params.days && params.days > 0) searchParams.set('days', String(params.days));
		if (params.step) searchParams.set('step', params.step);
		if (params.success !== undefined) searchParams.set('success', String(params.success));
		if (params.search) searchParams.set('search', params.search);
		const qs = searchParams.toString();
		return request<ExportEnvelope<Record<string, unknown>>>(`/audit-log/export${qs ? '?' + qs : ''}`);
	},

	// Event counts by processing_status (Audit page summary)
	getEventCounts: () => request<EventCountsResponse>('/events/counts'),

	// Per-day event shape for the timeline view: density buckets, per-platform
	// counts, and calendar meetings. Cards alone can't answer any of the three —
	// meetings carry their real start/end only on the source event.
	getDayEvents: (params: { date: string; spaceIds?: string[]; tz?: string; bucketMinutes?: number }) => {
		const searchParams = new URLSearchParams({ date: params.date });
		if (params.spaceIds?.length) searchParams.set('space_id', params.spaceIds.join(','));
		if (params.tz) searchParams.set('tz', params.tz);
		if (params.bucketMinutes) searchParams.set('bucket_minutes', String(params.bucketMinutes));
		return request<DayEventsResponse>(`/events/day?${searchParams.toString()}`);
	},

	// Outstanding failure counts — one-shot startup seed for the red-dot indicator
	getAuditFailureSummary: () => request<AuditFailureSummary>('/audit/failure-summary'),

	// Ingestion Errors
	getIngestionErrors: (params?: {
		space_id?: string;
		source_id?: string;
		unacknowledged_only?: boolean;
		include_cleared?: boolean;
		limit?: number;
		offset?: number;
	}) => {
		const searchParams = new URLSearchParams();
		if (params?.space_id) searchParams.set('space_id', params.space_id);
		if (params?.source_id) searchParams.set('source_id', params.source_id);
		if (params?.unacknowledged_only) searchParams.set('unacknowledged_only', 'true');
		if (params?.include_cleared) searchParams.set('include_cleared', 'true');
		if (params?.limit) searchParams.set('limit', String(params.limit));
		if (params?.offset) searchParams.set('offset', String(params.offset));
		const qs = searchParams.toString();
		return request<IngestionErrorsResponse>(`/ingestion-errors${qs ? '?' + qs : ''}`);
	},

	clearIngestionError: (errorId: string) =>
		request<ClearIngestionErrorsResponse>(`/ingestion-errors/${encodeURIComponent(errorId)}/clear`, {
			method: 'POST'
		}),

	clearAllIngestionErrors: (params?: { space_id?: string; source_id?: string }) => {
		const searchParams = new URLSearchParams();
		if (params?.space_id) searchParams.set('space_id', params.space_id);
		if (params?.source_id) searchParams.set('source_id', params.source_id);
		const qs = searchParams.toString();
		return request<ClearIngestionErrorsResponse>(
			`/ingestion-errors/clear-all${qs ? '?' + qs : ''}`,
			{ method: 'POST' }
		);
	},

	// Egress
	egressExecute: (data: EgressExecuteRequest) =>
		request<EgressExecuteResponse>('/egress/execute', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	egressPreview: (data: EgressExecuteRequest) =>
		request<EgressPreviewResponse>('/egress/preview', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	getEgressCapabilities: (platform: string) =>
		request<EgressCapabilitiesResponse>(`/egress/capabilities/${platform}`),

	getComposePlatforms: () =>
		request<ComposePlatformsResponse>('/egress/compose-platforms'),

	getCardEgressContext: (cardId: string) =>
		request<CardEgressContext>(`/egress/card-context/${encodeURIComponent(cardId)}`),

	listEgressConnections: () => request<EgressConnectionsResponse>('/egress/connections'),

	egressAiAssist: (data: EgressAiAssistRequest) =>
		request<EgressAiAssistResponse>('/egress/ai-assist', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	egressPolish: (text: string, platform: string) =>
		request<{ polished: string }>('/egress/polish', {
			method: 'POST',
			body: JSON.stringify({ text, platform })
		}),

	fieldSuggestions: (q: string, scope: string = 'all', platform: string = '', sources: string[] = ['email']) =>
		request<{ suggestions: string[] }>(`/egress/field-suggestions?q=${encodeURIComponent(q)}&scope=${scope}&platform=${encodeURIComponent(platform)}&sources=${sources.join(',')}`),

	emailSuggestions: (q: string) =>
		request<{ suggestions: string[] }>(`/egress/email-suggestions?q=${encodeURIComponent(q)}`),

	getConnectionNames: (platform: string) =>
		request<{ names: string[] }>(`/egress/connections/names/${platform}`),

	createEgressConnection: (data: EgressConnectRequest) =>
		request<EgressConnectResponse>('/egress/connections', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	deleteEgressConnection: (connectionId: string) =>
		request<{ status: string }>(`/egress/connections/${connectionId}`, {
			method: 'DELETE'
		}),

	testEgressConnection: (connectionId: string) =>
		request<{ connection_id: string; valid: boolean; error?: string }>(
			`/egress/connections/test/${connectionId}`,
			{ method: 'POST' }
		),

	detectEmailProvider: (email: string) =>
		request<EmailProviderDetection>(`/egress/connections/detect?email=${encodeURIComponent(email)}`),

	startOAuthFlow: (platform: string, connectionName?: string, spaceId?: string, channelNames?: string[]) => {
		const params = new URLSearchParams({ platform });
		if (connectionName) params.set('connection_name', connectionName);
		if (spaceId) params.set('space_id', spaceId);
		if (channelNames && channelNames.length > 0) params.set('channel_names', channelNames.join(','));
		return request<OAuthStartResponse>(`/egress/connections/oauth/start?${params}`);
	},

	setupOAuthClient: (data: { platform: string; client_id: string; client_secret: string }) =>
		request<{ status: string; platform: string }>('/egress/connections/oauth/setup', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	getSlackChannels: (connectionId: string) =>
		request<{ channels: string[] }>(`/egress/connections/${connectionId}/channels`),

	updateSlackChannels: (connectionId: string, channels: string[]) =>
		request<{ channels: string[] }>(`/egress/connections/${connectionId}/channels`, {
			method: 'PUT',
			body: JSON.stringify({ channels })
		}),

	// Omni — rolling cross-platform summary
	getOmni: (spaceId = 'default', version?: number) => {
		const params = new URLSearchParams({ space_id: spaceId });
		if (version !== undefined) params.set('version', String(version));
		return request<OmniSnapshot>(`/omni?${params}`);
	},

	getOmniHistory: (spaceId = 'default', limit = 30) =>
		request<OmniHistoryResponse>(`/omni/history?space_id=${encodeURIComponent(spaceId)}&limit=${limit}`),

	getOmniTimeline: (spaceId = 'default') =>
		request<OmniTimelineResponse>(`/omni/timeline?space_id=${encodeURIComponent(spaceId)}`),

	triggerOmniResynthesis: (spaceId = 'default') =>
		request<{ status: string; snapshot_ids: string[]; space_id: string }>(`/omni/resynthesis?space_id=${encodeURIComponent(spaceId)}`, {
			method: 'POST'
		}),

	getOmniResynthesisStatus: (spaceId = 'default') =>
		request<OmniResynthesisStatus>(
			`/omni/resynthesis/status?space_id=${encodeURIComponent(spaceId)}`
		),

	// What moved between two snapshot versions. `base` is exclusive, `to`
	// inclusive; omitting either compares the latest version against the one
	// before it.
	getOmniChanges: (spaceId = 'default', base?: number, to?: number) => {
		const params = new URLSearchParams({ space_id: spaceId });
		if (base !== undefined) params.set('base', String(base));
		if (to !== undefined) params.set('to', String(to));
		return request<OmniChangesResponse>(`/omni/changes?${params}`);
	},

	// Trailing-window event counts for the volume bars and platform-mix stack.
	// Sent with the browser's zone so day buckets line up with the user's clock.
	getOmniVolume: (spaceId = 'default', days = 14) => {
		const params = new URLSearchParams({ space_id: spaceId, days: String(days) });
		const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
		if (tz) params.set('tz', tz);
		return request<OmniVolumeResponse>(`/omni/volume?${params}`);
	},

	// One call for the item page: the claim, its evidence cards (bucketed), its
	// lineage, and what it could NOT load. Replaces the old N+1 /cards/{id} fan-out.
	getOmniItem: (params: {
		spaceId?: string;
		version?: number;
		/** Version where a changelog entry last saw the item — lets the engine
		 *  serve the last live state of a line the displayed snapshot no longer
		 *  carries (resolved / compressed away). */
		at?: number;
		section?: string;
		itemKey: string;
	}) => {
		const qs = new URLSearchParams({ space_id: params.spaceId ?? 'default', item: params.itemKey });
		if (params.version !== undefined) qs.set('v', String(params.version));
		if (params.at !== undefined) qs.set('at', String(params.at));
		if (params.section) qs.set('section', params.section);
		const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
		if (tz) qs.set('tz', tz);
		return request<OmniItemResponse>(`/omni/item?${qs}`);
	},

	getOmniPins: (spaceId = 'default') =>
		request<OmniPinsResponse>(`/omni/pins?space_id=${encodeURIComponent(spaceId)}`),

	pinOmniItem: (data: { space_id: string; text: string; source_cards: string[]; platforms: string[] }) =>
		request<OmniPin>('/omni/pin', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	unpinOmniItem: (pinId: string) =>
		request<{ status: string; pin_id: string }>(`/omni/pin/${encodeURIComponent(pinId)}`, {
			method: 'DELETE'
		}),

	toggleOmniBookmark: (data: { space_id: string; source_card_id: string; bookmarked: boolean }) =>
		request<{ status: string; bookmarked: boolean }>('/omni/bookmark', {
			method: 'POST',
			body: JSON.stringify(data)
		}),

	// Tags
	listTags: (isSystem?: boolean) => {
		const qs = isSystem !== undefined ? `?is_system=${isSystem}` : '';
		return request<{ tags: Tag[] }>(`/tags${qs}`);
	},
	createTag: (data: { name: string; color?: string }) =>
		request<Tag>('/tags', { method: 'POST', body: JSON.stringify(data) }),
	updateTag: (tagId: number, data: { name?: string; color?: string }) =>
		request<Tag>(`/tags/${tagId}`, { method: 'PUT', body: JSON.stringify(data) }),
	deleteTag: (tagId: number) =>
		request<{ status: string }>(`/tags/${tagId}`, { method: 'DELETE' }),
	assignTag: (data: { tag_name_or_id: string | number; target_type: string; target_id: string; create_if_missing?: boolean }) =>
		request<{ status: string; tag_id: number; tag_name: string }>('/tags/assign', {
			method: 'POST',
			body: JSON.stringify(data)
		}),
	removeTag: (data: { tag_id: number; target_type: string; target_id: string }) =>
		request<{ status: string }>('/tags/unassign', {
			method: 'DELETE',
			body: JSON.stringify(data)
		}),
	getTagsFor: (targetType: string, targetId: string) =>
		request<{ tags: TagAssignment[] }>(`/tags/for/${targetType}/${encodeURIComponent(targetId)}`),

	// MCP server config + token management
	getMcpConfig: () => request<McpConfig>('/mcp/config'),
	updateMcpConfig: (body: McpConfigUpdate) =>
		request<McpConfig>('/mcp/config', { method: 'PUT', body: JSON.stringify(body) }),
	refreshMcpToken: () => request<McpToken>('/mcp/token/refresh', { method: 'POST' }),
	revealMcpToken: () => request<McpToken>('/mcp/token/reveal'),
	deleteMcpToken: () => request<{ status: string }>('/mcp/token', { method: 'DELETE' })
};
