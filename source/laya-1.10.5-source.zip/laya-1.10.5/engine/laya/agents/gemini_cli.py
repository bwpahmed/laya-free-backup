# Copyright 2026 Aayush Chawla
# SPDX-License-Identifier: Apache-2.0

"""Gemini CLI adapter for the CodingAgent protocol."""

from __future__ import annotations

import json
import re
from typing import Any, AsyncIterator

import structlog

from laya.agents.base import BaseCodingAgent
from laya.agents.subprocess_helper import AgentProcess, strip_ansi
from laya.models.workspace import (
    SessionStatus,
    WorkspaceEvent,
    WorkspaceEventActor,
    WorkspaceEventType,
)

log = structlog.get_logger()

APPROVAL_PATTERNS = [
    re.compile(r"Do you want to (proceed|continue)\?", re.IGNORECASE),
    re.compile(r"\[Y/n\]", re.IGNORECASE),
    re.compile(r"\(y/N\)", re.IGNORECASE),
]


class GeminiCliAgent(BaseCodingAgent):
    """Gemini CLI adapter.

    Spawns `gemini -p "<prompt>" --output-format stream-json` as a subprocess.
    Parses the JSON stream lines for structured events.  Non-JSON lines
    (credential messages, rate-limit retries, etc.) are wrapped as
    AGENT_MESSAGE events so nothing is lost.
    """

    def __init__(self, binary_path: str = "gemini") -> None:
        self._binary = binary_path
        self._process = AgentProcess()
        self._session_id: str = ""
        self._gemini_session_id: str | None = None
        self._repo_path: str = ""
        self._status: SessionStatus = SessionStatus.STARTING
        # Buffer for assembling delta message chunks
        self._delta_buffer: str = ""

    @property
    def cc_session_id(self) -> str | None:
        """Gemini's internal session UUID (stored in the generic cc_session_id column)."""
        return self._gemini_session_id

    async def start_session(
        self, session_id: str, prompt: str, repo_path: str, add_dirs: list[str] | None = None,
        mode: str | None = None, research: bool = False, space_id: str | None = None,
    ) -> None:
        # space_id: MCP wiring not implemented yet for Gemini CLI — see
        # GitHub issue for the tracking ticket. Configuration requires
        # writing ~/.gemini/settings.json, which is invasive to user settings.
        _ = space_id
        self._session_id = session_id
        self._repo_path = repo_path
        self._status = SessionStatus.STARTING

        args = [
            self._binary,
            "-p",
            prompt,
            "--output-format",
            "stream-json",
        ]

        if research:
            # Auto-approve file writes so the agent can save research output.
            # Gemini CLI has no CLI-level directory scoping — auto_edit approves
            # writes everywhere.  The cwd is set to the research directory and
            # the prompt instructs the agent to write only there, but this is
            # not enforced at the tool level (unlike Claude Code's --allowedTools
            # or Codex's OS-level sandbox).
            # Web search (Google Search) is always enabled — no flag needed.
            args.extend(["--approval-mode", "auto_edit"])

        if add_dirs:
            for d in add_dirs:
                args.extend(["--include-directories", d])

        await self._process.spawn(args=args, cwd=repo_path)
        self._status = SessionStatus.RUNNING

    async def resume_with_answer(
        self,
        answer_text: str,
        add_dirs: list[str] | None = None,
        research: bool = False,
        mode: str | None = None,
        space_id: str | None = None,
    ) -> None:
        # mode/space_id: accepted for protocol compatibility; not used by Gemini yet.
        _ = (mode, space_id)
        """Resume the Gemini CLI conversation with the user's answer.

        Spawns a new subprocess using --resume <session_id> so Gemini
        loads the conversation history and continues from where it left off.

        Args:
            answer_text: The user's response text.
            add_dirs: Extra directory paths to pass via --include-directories flags.
            research: If True, apply auto_edit approval mode for research writes.
        """
        if not self._gemini_session_id:
            raise ValueError("No Gemini session ID available for resumption")

        self._process = AgentProcess()
        self._status = SessionStatus.STARTING

        args = [
            self._binary,
            "-p",
            answer_text,
            "--resume",
            self._gemini_session_id,
            "--output-format",
            "stream-json",
        ]

        if research:
            # Same as start_session: auto-approve writes, web search is always on.
            # No CLI-level directory scoping available for Gemini.
            args.extend(["--approval-mode", "auto_edit"])

        if add_dirs:
            for d in add_dirs:
                args.extend(["--include-directories", d])

        await self._process.spawn(args=args, cwd=self._repo_path)
        self._status = SessionStatus.RUNNING

    async def stream_events(self) -> AsyncIterator[WorkspaceEvent]:
        """Parse Gemini CLI's stream-json output into WorkspaceEvents."""
        yield self._make_event(
            WorkspaceEventType.STATUS_CHANGE,
            WorkspaceEventActor.SYSTEM,
            {"status": "running", "agent": "gemini_cli"},
        )

        self._delta_buffer = ""

        async for raw_line in self._process.read_lines():
            line = strip_ansi(raw_line).strip()
            if not line:
                continue

            # Try to parse as JSON (stream-json format)
            events = self._parse_stream_json(line)
            if events is not None:
                for event in events:
                    yield event
                continue

            # Non-JSON line: credential messages, rate-limit retries, etc.
            # Flush any pending delta buffer first
            flushed = self._flush_delta_buffer()
            if flushed:
                yield flushed

            # Check for approval prompts in plain-text lines
            if any(p.search(line) for p in APPROVAL_PATTERNS):
                self._status = SessionStatus.AWAITING_INPUT
                yield self._make_event(
                    WorkspaceEventType.APPROVAL_REQUEST,
                    WorkspaceEventActor.AGENT,
                    {"message": line},
                    requires_input=True,
                )
            else:
                # Wrap non-JSON output as a system message so it's persisted
                yield self._make_event(
                    WorkspaceEventType.AGENT_MESSAGE,
                    WorkspaceEventActor.SYSTEM,
                    {"text": line, "raw": True},
                )

        # Flush any remaining delta buffer at end of stream
        flushed = self._flush_delta_buffer()
        if flushed:
            yield flushed

        exit_code = await self._process.wait()
        yield self._terminal_status_event(exit_code)

    def _parse_stream_json(self, line: str) -> list[WorkspaceEvent] | None:
        """Parse a stream-json line from Gemini CLI into workspace events.

        Returns a list of events (possibly empty if the line was parsed
        successfully but produced no events, e.g. delta chunks being buffered),
        or ``None`` if the line is not valid JSON.

        Gemini stream-json types:
        - init: session metadata (session_id, model)
        - message (role=user): echoed user prompt
        - message (role=assistant, delta=true): streaming assistant chunks
        - message (role=assistant, no delta): complete assistant message
        - tool_use: tool invocation
        - tool_result: tool output
        - result: final session stats
        """
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            return None

        msg_type = data.get("type", "")

        # --- init: capture session_id and model ---
        if msg_type == "init":
            sid = data.get("session_id")
            if sid:
                self._gemini_session_id = sid
                log.info("gemini_session_id_captured", gemini_session_id=sid)
            meta: dict[str, Any] = {"status": "init"}
            if "model" in data:
                meta["model"] = data["model"]
            if "session_id" in data:
                meta["session_id"] = data["session_id"]
            return [
                self._make_event(
                    WorkspaceEventType.STATUS_CHANGE,
                    WorkspaceEventActor.SYSTEM,
                    meta,
                )
            ]

        # --- message ---
        if msg_type == "message":
            role = data.get("role", "")
            content = data.get("content", "")
            is_delta = data.get("delta", False)

            # User message echo — just record it
            if role == "user":
                return [
                    self._make_event(
                        WorkspaceEventType.AGENT_MESSAGE,
                        WorkspaceEventActor.SYSTEM,
                        {"text": content, "echoed_prompt": True},
                    )
                ]

            # Assistant message
            if role == "assistant":
                if is_delta:
                    # Accumulate delta chunks into buffer
                    self._delta_buffer += content
                    return []
                else:
                    # Complete message (non-delta) — emit directly
                    return [
                        self._make_event(
                            WorkspaceEventType.AGENT_MESSAGE,
                            WorkspaceEventActor.AGENT,
                            {"text": content},
                        )
                    ]

            return []

        # --- tool_use ---
        if msg_type == "tool_use":
            tool_name = data.get("tool_name", "unknown")
            tool_id = data.get("tool_id", "")
            params = data.get("parameters", {})

            evt_type = self._classify_tool(tool_name)
            tool_content: dict[str, Any] = {
                "tool": tool_name,
                "input": params,
                "tool_id": tool_id,
            }
            if evt_type in (WorkspaceEventType.FILE_READ, WorkspaceEventType.FILE_WRITE):
                tool_content["file"] = params.get("file_path", "")

            # Flush delta buffer before tool use — the preceding text is the
            # agent's reasoning before invoking the tool
            events: list[WorkspaceEvent] = []
            flushed = self._flush_delta_buffer()
            if flushed:
                events.append(flushed)
            events.append(self._make_event(evt_type, WorkspaceEventActor.AGENT, tool_content))
            return events

        # --- tool_result ---
        if msg_type == "tool_result":
            tool_id = data.get("tool_id", "")
            status = data.get("status", "")
            output = data.get("output", "")
            error = data.get("error")
            result_content: dict[str, Any] = {
                "tool_id": tool_id,
                "status": status,
                "output": output,
            }
            if error:
                result_content["error"] = error
            return [
                self._make_event(
                    WorkspaceEventType.TOOL_CALL,
                    WorkspaceEventActor.SYSTEM,
                    result_content,
                )
            ]

        # --- result: final session stats ---
        if msg_type == "result":
            stats = data.get("stats", {})
            return [
                self._make_event(
                    WorkspaceEventType.STATUS_CHANGE,
                    WorkspaceEventActor.SYSTEM,
                    {
                        "status": "result_received",
                        "result_status": data.get("status", ""),
                        "stats": stats,
                    },
                )
            ]

        return []

    def _flush_delta_buffer(self) -> WorkspaceEvent | None:
        """Flush accumulated delta chunks as a single AGENT_MESSAGE event."""
        if not self._delta_buffer:
            return None
        text = self._delta_buffer
        self._delta_buffer = ""
        return self._make_event(
            WorkspaceEventType.AGENT_MESSAGE,
            WorkspaceEventActor.AGENT,
            {"text": text},
        )

    @staticmethod
    def _classify_tool(tool_name: str) -> WorkspaceEventType:
        """Map a Gemini tool name to the appropriate WorkspaceEventType."""
        if tool_name in ("read_file", "ReadFile", "Read"):
            return WorkspaceEventType.FILE_READ
        if tool_name in ("write_file", "WriteFile", "Write", "edit_file", "Edit", "replace_in_file"):
            return WorkspaceEventType.FILE_WRITE
        return WorkspaceEventType.TOOL_CALL

