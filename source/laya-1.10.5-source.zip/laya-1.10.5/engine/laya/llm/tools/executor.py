# Copyright 2026 Aayush Chawla
# SPDX-License-Identifier: Apache-2.0

"""Tool execution dispatcher — routes tool calls to implementations."""

from __future__ import annotations

import json
from typing import Any

import structlog

from laya.egress.tool_handlers import (
    handle_confirm_egress,
    handle_egress_tool,
    handle_open_compose,
)
from laya.egress.tools import PREVIEWABLE_EGRESS_TOOLS
from laya.llm.tools import card_tools, entity_tools, event_tools, rules_tools, search_tools, settings_tools, summary_tools

log = structlog.get_logger()

# Registry: tool_name -> async handler function
_TOOL_HANDLERS: dict[str, Any] = {}


def _register_tools() -> None:
    """Build the handler registry from all tool modules."""
    global _TOOL_HANDLERS
    if _TOOL_HANDLERS:
        return

    _TOOL_HANDLERS = {
        # Read tools
        "search_cards": card_tools.search_cards,
        "get_card": card_tools.get_card,
        "get_card_stats": card_tools.get_card_stats,
        "get_cards_for_event": card_tools.get_cards_for_event,
        "get_cards_by_entity": card_tools.get_cards_by_entity,
        "search_events": event_tools.search_events,
        "get_event": event_tools.get_event,
        "get_recent_activity": event_tools.get_recent_activity,
        "search_entities": entity_tools.search_entities,
        "get_entity": entity_tools.get_entity,
        "semantic_search": search_tools.semantic_search,
        "get_daily_summary": summary_tools.get_daily_summary,
        "get_omni_summary": summary_tools.get_omni_summary,
        # Write tools
        "dismiss_card": card_tools.dismiss_card,
        "mark_card_done": card_tools.mark_card_done,
        "archive_card": card_tools.archive_card,
        "reopen_card": card_tools.reopen_card,
        "retry_card": card_tools.retry_card,
        # Settings tools
        "get_settings": settings_tools.get_settings,
        "update_theme": settings_tools.update_theme,
        "update_retention": settings_tools.update_retention,
        "update_briefing": settings_tools.update_briefing,
        "update_notifications": settings_tools.update_notifications,
        "update_feed_preferences": settings_tools.update_feed_preferences,
        "update_smart_grouping": settings_tools.update_smart_grouping,
        # Rule tools
        "list_rules": rules_tools.list_rules,
        "get_rule_options": rules_tools.get_rule_options,
        "create_filter_rule": rules_tools.create_filter_rule,
        "create_classification_rule": rules_tools.create_classification_rule,
        "create_processing_rule": rules_tools.create_processing_rule,
        "update_rule": rules_tools.update_rule,
        "delete_rule": rules_tools.delete_rule,
    }


async def execute_tool(
    name: str,
    arguments: dict[str, Any],
    space_id: str | None = None,
) -> str:
    """Execute a tool by name and return the result as a JSON string.

    Args:
        name: The tool function name.
        arguments: The tool arguments from the LLM.
        space_id: Optional space context for filtering.

    Returns:
        JSON string result to feed back to the LLM.
    """
    _register_tools()

    # Egress tools — handled by the egress module
    if name == "open_compose":
        return await handle_open_compose(arguments, space_id)
    if name == "confirm_egress":
        return await handle_confirm_egress(arguments, space_id)
    if name == "find_contact":
        from laya.llm.tools.contact_tools import find_contact
        query = arguments.get("query", "")
        result = await find_contact(query)
        return json.dumps(result, default=str)
    if name in PREVIEWABLE_EGRESS_TOOLS:
        return await handle_egress_tool(name, arguments, space_id)

    handler = _TOOL_HANDLERS.get(name)
    if not handler:
        return json.dumps({"error": f"Unknown tool: {name}"})

    try:
        # Inject space_id for tools that accept it
        import inspect
        sig = inspect.signature(handler)
        if "space_id" in sig.parameters:
            arguments["space_id"] = space_id

        result = await handler(**arguments)
        return json.dumps(result, default=str)
    except Exception as e:
        log.error("tool_execution_failed", tool=name, error=str(e))
        # Persist the crash to the audit log — log.error alone is ephemeral and gets
        # rotated away, leaving no record that a chat tool failed. Never let auditing
        # break the error path. Local import avoids an import cycle with the LLM client.
        try:
            from laya.llm.client import log_to_audit

            await log_to_audit(
                event_id=None, card_id=None, step="tool",
                model="n/a", input_tokens=0, output_tokens=0, latency_ms=0,
                success=False, error=str(e),
                metadata={"tool": name, "source": "chat"},
            )
        except Exception:
            pass
        return json.dumps({"error": f"Tool '{name}' failed: {str(e)}"})
