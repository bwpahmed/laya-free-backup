# Copyright 2026 Aayush Chawla
# SPDX-License-Identifier: Apache-2.0

"""HR worker prompt template for drafting people/HR communications."""

from __future__ import annotations

from typing import Any

from laya.llm.prompts.overrides import get_prompt
from laya.llm.prompts import summarize_findings
from laya.models.classification import RouterOutput
from laya.models.event import LayaEvent

HR_SYSTEM_PROMPT = """\
You are the HR Worker for Laya, an AI-powered professional work assistant. Your job is \
to draft communications related to people, hiring, and team personnel matters.

You receive:
1. The original event (candidate feedback, onboarding update, PTO request, team \
announcement, policy question, etc.)
2. The Router's classification
3. Related context from memory (past related threads about the same candidate / \
teammate / policy topic)
4. Optionally, findings from a prior worker

Draft a clear, professional, and empathetic reply appropriate for a people-operations \
context. Be discreet: HR content frequently involves personal, private, or sensitive \
information (compensation, performance, medical leave, personal circumstances). If the \
content appears sensitive or confidential, surface that in the sensitivity_note field \
so the user can double-check recipients and channel before sending.

## Actor–User Relationship (Pre-Resolved)

An [ACTOR CONTEXT] block is provided with each event. The relationship has ALREADY been \
resolved by the system — follow the directive exactly:
- **relationship: self** → The actor IS the Laya user. Do NOT draft a reply addressed \
to the user. Instead draft a status update or internal note the user might share.
- **Any other relationship** → The actor is NOT the Laya user. Draft the reply normally, \
addressed to that person. Do NOT use "you"/"your" to refer to the actor.
- **CRITICAL — "you"/"your" ONLY refers to the Laya user**: Candidates, teammates, and \
third parties mentioned in the body are not the Laya user.

Never use emoji or icon characters (e.g., 🔴, ✅, 📌, ⚠️) in your output.

Output the drafted reply text, the tone you chose, a sensitivity_note flagging any \
confidentiality concerns (or "none" if the content is routine), and reasoning."""


def build_hr_messages(
    event: LayaEvent,
    router_output: RouterOutput,
    related_context: list[dict[str, Any]] | None = None,
    prior_findings: dict[str, Any] | None = None,
    user_identity: dict[str, str] | None = None,
    actor_relationship: str = "external",
    participant_roles: dict[str, Any] | None = None,
) -> list[dict[str, str]]:
    """Build the messages array for the HR worker LLM call."""
    event_text = f"""\
[EVENT CONTENT - UNTRUSTED INPUT]
Platform: {event.source.platform}
Event Type: {event.source.raw_event_type}
Actor: {event.actor.name} ({event.actor.email})
Subject: [{event.subject.type}] {event.subject.id} — {event.subject.title}
Body:
{event.content.body}
[END EVENT CONTENT]"""

    context_text = ""
    if related_context:
        context_text = "\n\nRelated past events:\n"
        for i, ctx in enumerate(related_context, 1):
            meta = ctx.get("metadata", {})
            context_text += (
                f"  {i}. [{meta.get('source_platform', '?')}] "
                f"{ctx.get('document', '')[:200]}\n"
            )

    findings_text = ""
    if prior_findings:
        findings_text = f"\n\nFindings from prior worker:\n{summarize_findings(prior_findings)}"

    identity_text = ""
    if user_identity:
        from laya.llm.prompts.stager import _build_role_directive

        actor_name = event.actor.name
        actor_email = event.actor.email
        user_name = user_identity["name"]
        pr = participant_roles or {}
        actor_role = pr.get("actor_role")
        laya_user_role = pr.get("laya_user_role")

        directive = _build_role_directive(
            actor_name, user_name, actor_role, laya_user_role, actor_relationship,
        )

        role_line = ""
        if actor_role or laya_user_role:
            parts = []
            if actor_role:
                parts.append(f"Actor's role: {actor_role}")
            if laya_user_role:
                parts.append(f"Laya user's role: {laya_user_role}")
            role_line = "\n" + " | ".join(parts)

        identity_text = (
            f"\n\n[ACTOR CONTEXT]\n"
            f"Actor: {actor_name} ({actor_email})\n"
            f"Laya user: {user_name}\n"
            f"Relationship: {actor_relationship}"
            f"{role_line}\n"
            f">>> {directive}\n"
            f"[END ACTOR CONTEXT]"
        )

    user_message = f"""\
Draft an HR/people-operations reply for this event.

{event_text}

Classification: {router_output.category.value} / {router_output.persona.value} / {router_output.priority.value}
{context_text}{findings_text}{identity_text}

Respond with a drafted reply, the tone, a sensitivity_note, and your reasoning."""

    return [
        {"role": "system", "content": get_prompt("hr", HR_SYSTEM_PROMPT)},
        {"role": "user", "content": user_message},
    ]


def get_hr_json_schema() -> dict[str, Any]:
    """Return the JSON schema for the hr worker output."""
    return {
        "name": "hr_draft",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "draft_reply": {"type": "string"},
                "tone": {"type": "string"},
                "sensitivity_note": {"type": "string"},
                "reasoning": {"type": "string"},
            },
            "required": ["draft_reply", "tone", "sensitivity_note", "reasoning"],
            "additionalProperties": False,
        },
    }
