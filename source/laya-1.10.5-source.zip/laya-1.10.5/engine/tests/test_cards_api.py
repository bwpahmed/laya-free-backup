# Copyright 2026 Aayush Chawla
# SPDX-License-Identifier: Apache-2.0

"""Tests for the Cards REST API."""

import asyncio
import json
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from tests.conftest import insert_test_card, insert_test_event


@pytest.mark.asyncio
class TestCardsAPI:
    async def test_get_cards_empty(self, db):
        """GET /cards returns empty list when no cards exist."""
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards")

        assert resp.status_code == 200
        data = resp.json()
        assert data["cards"] == []
        assert data["total"] == 0

    async def test_get_cards_with_data(self, db):
        """GET /cards returns cards when they exist."""
        await insert_test_card(db, "card_1", "evt_1")
        await insert_test_card(db, "card_2", "evt_2", priority="CRITICAL")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["cards"]) == 2

    async def test_get_cards_filter_by_status(self, db):
        """GET /cards?status=pending filters correctly."""
        await insert_test_card(db, "card_p", "evt_p", status="pending")
        await insert_test_card(db, "card_d", "evt_d", status="done")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards?status=pending")

        data = resp.json()
        assert data["total"] == 1
        assert data["cards"][0]["card_id"] == "card_p"

    async def test_get_cards_filter_by_priority(self, db):
        """GET /cards?priority=CRITICAL filters correctly."""
        await insert_test_card(db, "card_h", "evt_h", priority="HIGH")
        await insert_test_card(db, "card_c", "evt_c", priority="CRITICAL")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards?priority=CRITICAL")

        data = resp.json()
        assert data["total"] == 1
        assert data["cards"][0]["priority"] == "CRITICAL"

    async def test_get_card_detail(self, db):
        """GET /cards/:card_id returns full card detail."""
        await insert_test_card(db)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards/card_test")

        assert resp.status_code == 200
        data = resp.json()
        assert data["card_id"] == "card_test"
        assert data["header"] == "Test Card Header"
        assert data["intelligence"] == ["Finding 1", "Finding 2"]
        assert data["staged_output"]["type"] == "code_fix"
        assert len(data["suggested_actions"]) == 1

    async def test_get_card_404(self, db):
        """GET /cards/:card_id returns 404 for non-existent card."""
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards/card_nonexistent")

        assert resp.status_code == 404

    async def test_mark_card_done(self, db):
        """POST /cards/:card_id/done updates status to done."""
        await insert_test_card(db, status="pending")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/done", json={})

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "done"
        assert data["card_id"] == "card_test"

        # Verify DB
        rows = await db.execute_fetchall(
            "SELECT status, resolved_at FROM action_cards WHERE card_id = ?",
            ("card_test",),
        )
        assert rows[0]["status"] == "done"
        assert rows[0]["resolved_at"] is not None

    async def test_mark_card_done_from_ready(self, db):
        """POST /cards/:card_id/done works for cards in 'ready' status."""
        await insert_test_card(db, status="ready")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/done", json={})

        assert resp.status_code == 200
        assert resp.json()["status"] == "done"

    async def test_mark_card_done_409_on_terminal(self, db):
        """POST /cards/:card_id/done returns 409 if card is already done."""
        await insert_test_card(db, status="done")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/done", json={})

        assert resp.status_code == 409

    async def test_dismiss_card(self, db):
        """POST /cards/:card_id/dismiss stores feedback and updates status."""
        await insert_test_card(db)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/cards/card_test/dismiss",
                json={"reason": "Not relevant", "feedback_type": "irrelevant"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "dismissed"

        rows = await db.execute_fetchall(
            "SELECT status, user_feedback, feedback_type FROM action_cards WHERE card_id = ?",
            ("card_test",),
        )
        assert rows[0]["status"] == "dismissed"
        assert rows[0]["user_feedback"] == "Not relevant"
        assert rows[0]["feedback_type"] == "irrelevant"

    async def test_dismiss_card_409_on_terminal(self, db):
        """POST /cards/:card_id/dismiss returns 409 if card is in terminal state."""
        await insert_test_card(db, status="dismissed")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/dismiss", json={})

        assert resp.status_code == 409

    async def test_dismiss_from_agent_running_status(self, db):
        """POST /cards/:card_id/dismiss works for cards in 'agent_running' status."""
        await insert_test_card(db, status="agent_running")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/cards/card_test/dismiss",
                json={"reason": "Cancelled by user"},
            )

        assert resp.status_code == 200
        assert resp.json()["status"] == "dismissed"

    async def test_dismiss_done_returns_409(self, db):
        """POST /cards/:card_id/dismiss returns 409 for done cards."""
        await insert_test_card(db, status="done")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/dismiss", json={})

        assert resp.status_code == 409

    async def test_dismiss_failed_succeeds(self, db):
        """POST /cards/:card_id/dismiss succeeds for failed cards (failed -> dismissed is valid)."""
        await insert_test_card(db, status="failed")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/dismiss", json={})

        assert resp.status_code == 200


@pytest.mark.asyncio
class TestActionPayloadPolish:
    async def test_polish_flips_flags_and_writes_polished_text(self, db):
        """POST /cards/:id/action-payload/polish writes polished text back to the action."""
        await insert_test_card(db, status="ready")

        fake_response = type("R", (), {"content": "Polished reply body.", "parsed": {"polished": "Polished reply body."}})()
        from laya.main import app

        with patch("laya.llm.client.llm_call", new=AsyncMock(return_value=fake_response)):
            transport = ASGITransport(app=app)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(
                    "/cards/card_test/action-payload/polish",
                    json={"action_id": "act_1"},
                )
                assert resp.status_code == 200
                assert resp.json()["status"] == "polishing"

                # Drain background tasks so the polish finishes before we read DB
                await asyncio.sleep(0)
                for _ in range(20):
                    pending = [t for t in asyncio.all_tasks() if t.get_name().startswith("polish_")]
                    if not pending:
                        break
                    await asyncio.gather(*pending, return_exceptions=True)

        rows = await db.execute_fetchall(
            "SELECT suggested_actions FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        actions = json.loads(rows[0]["suggested_actions"])
        payload = actions[0]["payload"]
        assert payload["body"] == "Polished reply body."
        assert payload["_polishing"] is False
        assert "_polished_at" in payload

    async def test_polish_conflict_when_already_polishing(self, db):
        """A second polish request returns 409 while one is in flight."""
        await insert_test_card(db, status="ready")
        # Seed the action as already polishing
        rows = await db.execute_fetchall(
            "SELECT suggested_actions FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        actions = json.loads(rows[0]["suggested_actions"])
        actions[0]["payload"]["_polishing"] = True
        await db.execute(
            "UPDATE action_cards SET suggested_actions = ? WHERE card_id = ?",
            (json.dumps(actions), "card_test"),
        )
        await db.commit()

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/cards/card_test/action-payload/polish",
                json={"action_id": "act_1"},
            )

        assert resp.status_code == 409

    async def test_polish_unknown_action_returns_404(self, db):
        await insert_test_card(db, status="ready")
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/cards/card_test/action-payload/polish",
                json={"action_id": "does_not_exist"},
            )
        assert resp.status_code == 404

    async def test_update_action_payload_sets_edited_flag(self, db):
        """The existing update endpoint flips `_edited: true` so the Polish link can appear."""
        await insert_test_card(db, status="ready")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/cards/card_test/action-payload",
                json={"action_id": "act_1", "payload": {"body": "User edit"}},
            )
            assert resp.status_code == 200

        rows = await db.execute_fetchall(
            "SELECT suggested_actions FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        payload = json.loads(rows[0]["suggested_actions"])[0]["payload"]
        assert payload["body"] == "User edit"
        assert payload["_edited"] is True

    # ── Read / Unread tracking ──────────────────────────────────────────

    async def test_mark_card_read(self, db):
        """POST /cards/:id/read sets read_at timestamp."""
        await insert_test_card(db, status="ready")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/read")

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "read"
        assert data["read_at"] is not None

        rows = await db.execute_fetchall(
            "SELECT read_at FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        assert rows[0]["read_at"] is not None

    async def test_mark_card_read_idempotent(self, db):
        """Calling read twice returns already_read without changing timestamp."""
        await insert_test_card(db, status="ready")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp1 = await client.post("/cards/card_test/read")
            first_read_at = resp1.json()["read_at"]

            resp2 = await client.post("/cards/card_test/read")
            assert resp2.json()["status"] == "already_read"
            assert resp2.json()["read_at"] == first_read_at

    async def test_mark_card_read_404(self, db):
        """POST /cards/:id/read returns 404 for non-existent card."""
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/nonexistent/read")
        assert resp.status_code == 404

    async def test_mark_group_read(self, db):
        """POST /cards/group/:entity_id/read-all marks all group cards as read."""
        entity = "jira:ticket:GROUP-1"
        await insert_test_card(db, "c1", "e1", entity_id=entity)
        await insert_test_card(db, "c2", "e2", entity_id=entity)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(f"/cards/group/{entity}/read-all")

        assert resp.status_code == 200
        assert resp.json()["marked"] == 2

        rows = await db.execute_fetchall(
            "SELECT read_at FROM action_cards WHERE entity_id = ?", (entity,)
        )
        assert all(r["read_at"] is not None for r in rows)

    async def test_mark_all_read(self, db):
        """POST /cards/read-all marks all unread cards as read."""
        await insert_test_card(db, "c1", "e1")
        await insert_test_card(db, "c2", "e2")

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/read-all")

        assert resp.status_code == 200
        assert resp.json()["marked"] == 2

    async def test_mark_done_sets_read_at(self, db):
        """Marking a card as done implicitly sets read_at."""
        await insert_test_card(db, status="ready")

        rows_before = await db.execute_fetchall(
            "SELECT read_at FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        assert rows_before[0]["read_at"] is None

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            await client.post("/cards/card_test/done")

        rows_after = await db.execute_fetchall(
            "SELECT read_at FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        assert rows_after[0]["read_at"] is not None

    async def test_card_detail_includes_read_at(self, db):
        """GET /cards/:id response includes read_at field."""
        await insert_test_card(db)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/cards/card_test")

        data = resp.json()
        assert "read_at" in data
        assert data["read_at"] is None


async def _setup_context_group(db, context_id="ctx_test123"):
    """Create two entity groups linked by a context_id."""
    await insert_test_event(db, "evt_jira1", platform="jira",
                            subject_title="NPE in PaymentService")
    await insert_test_event(db, "evt_gmail1", platform="gmail",
                            subject_title="RE: PaymentService crash")
    await db.execute(
        """INSERT INTO action_cards
           (card_id, event_id, priority, persona, category, header, summary,
            intelligence, staged_output, suggested_actions, status, privacy_tier,
            entity_id, context_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("card_jira", "evt_jira1", "HIGH", "ENGINEER", "CODE",
         "Jira: NPE in PaymentService", "Null pointer exception",
         "[]", "{}", "[]", "pending", 2,
         "jira:ticket:PAY-101", context_id),
    )
    await db.execute(
        """INSERT INTO action_cards
           (card_id, event_id, priority, persona, category, header, summary,
            intelligence, staged_output, suggested_actions, status, privacy_tier,
            entity_id, context_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("card_gmail", "evt_gmail1", "MEDIUM", "COMMS", "EMAIL",
         "Gmail: RE: PaymentService crash", "Thread about crash",
         "[]", "{}", "[]", "pending", 2,
         "gmail:email_thread:thr-456", context_id),
    )
    await db.execute(
        "INSERT INTO context_groups (context_id, label) VALUES (?, ?)",
        (context_id, "PaymentService outage"),
    )
    await db.execute(
        "INSERT OR IGNORE INTO context_group_members (context_id, card_id, confidence, link_method) VALUES (?, ?, ?, ?)",
        (context_id, "card_jira", 0.85, "semantic"),
    )
    await db.execute(
        "INSERT OR IGNORE INTO context_group_members (context_id, card_id, confidence, link_method) VALUES (?, ?, ?, ?)",
        (context_id, "card_gmail", 0.85, "semantic"),
    )
    await db.commit()


@pytest.mark.asyncio
class TestContextGrouping:
    """Tests for context_id-based feed grouping (smart_display)."""

    async def test_context_groups_merge_entity_groups(self, db):
        """Two entity groups sharing a context_id are merged into one feed group."""
        await _setup_context_group(db)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            with patch("laya.config.load_settings", return_value={
                "smart_grouping": {"smart_display": True, "context_association": True},
            }):
                resp = await client.get("/cards/grouped")

        data = resp.json()
        assert data["total_groups"] == 1
        group = data["groups"][0]
        assert group["context_id"] == "ctx_test123"
        assert group["context_label"] == "PaymentService outage"
        assert group["card_count"] == 2
        assert group["platforms"] is not None
        assert set(group["platforms"]) == {"jira", "gmail"}

    async def test_smart_display_off_keeps_entity_groups(self, db):
        """When smart_display=False, entity groups are not merged."""
        await _setup_context_group(db)

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            with patch("laya.config.load_settings", return_value={
                "smart_grouping": {"smart_display": False},
            }):
                resp = await client.get("/cards/grouped")

        data = resp.json()
        assert data["total_groups"] == 2
        for g in data["groups"]:
            assert g["context_id"] is None

    async def test_user_split_excluded_from_context_grouping(self, db):
        """Context groups with user_split=TRUE are not merged."""
        await _setup_context_group(db)
        await db.execute(
            "UPDATE context_groups SET user_split = 1 WHERE context_id = ?",
            ("ctx_test123",),
        )
        await db.commit()

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            with patch("laya.config.load_settings", return_value={
                "smart_grouping": {"smart_display": True, "context_association": True},
            }):
                resp = await client.get("/cards/grouped")

        data = resp.json()
        assert data["total_groups"] == 2

    async def test_single_entity_context_not_decorated(self, db):
        """A context group with only 1 entity_id renders as a normal entity group."""
        await insert_test_event(db, "evt_j1", platform="jira",
                                subject_title="Bug report")
        await insert_test_event(db, "evt_j2", platform="jira",
                                subject_title="Bug report update")
        entity = "jira:ticket:BUG-99"
        ctx = "ctx_singleentity"
        for i, eid in enumerate(["evt_j1", "evt_j2"]):
            await db.execute(
                """INSERT INTO action_cards
                   (card_id, event_id, priority, persona, category, header, summary,
                    intelligence, staged_output, suggested_actions, status, privacy_tier,
                    entity_id, context_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (f"card_se{i}", eid, "HIGH", "ENGINEER", "CODE",
                 f"Card {i}", "Summary", "[]", "{}", "[]", "pending", 2,
                 entity, ctx),
            )
        await db.execute(
            "INSERT INTO context_groups (context_id, label) VALUES (?, ?)",
            (ctx, "Bug context"),
        )
        await db.commit()

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            with patch("laya.config.load_settings", return_value={
                "smart_grouping": {"smart_display": True, "context_association": True},
            }):
                resp = await client.get("/cards/grouped")

        data = resp.json()
        assert data["total_groups"] == 1
        group = data["groups"][0]
        # Should be a normal entity group, not a context group
        assert group["context_id"] is None
        assert group["entity_id"] == entity


@pytest.mark.asyncio
class TestGroupedPrevNextDates:
    async def test_prev_next_dates_use_local_tz(self, db):
        """prev/next pagination converts each boundary card's UTC group_active_at
        to the user's LOCAL date via an indexed range lookup (DST-correct) —
        review P4-16 (no fixed-offset DATE()-per-row full scan)."""
        await insert_test_card(db, "card_p", "evt_p", entity_id="jira:ticket:A")
        await insert_test_card(db, "card_t", "evt_t", entity_id="jira:ticket:B")
        await insert_test_card(db, "card_n", "evt_n", entity_id="jira:ticket:C")
        # Noon UTC on three consecutive days → local date = same day in EST (UTC-5).
        for cid, ts in (
            ("card_p", "2026-01-10 12:00:00"),
            ("card_t", "2026-01-11 12:00:00"),
            ("card_n", "2026-01-12 12:00:00"),
        ):
            await db.execute(
                "UPDATE action_cards SET group_active_at = ? WHERE card_id = ?", (ts, cid)
            )
        await db.commit()

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get(
                "/cards/grouped?date=2026-01-11&tz=America/New_York"
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["prev_date"] == "2026-01-10"
        assert data["next_date"] == "2026-01-12"


@pytest.mark.asyncio
class TestReopenCardSSOT:
    async def test_reopen_dismissed_restores_previous_status(self, db):
        """Reopening a dismissed card restores its saved previous_status through the
        lifecycle SSOT (allow_restore), clearing resolved_at/previous_status (P7-4)."""
        await insert_test_card(db, status="pending")
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            await client.post("/cards/card_test/dismiss", json={})  # saves previous_status=pending
            resp = await client.post("/cards/card_test/reopen")

        assert resp.status_code == 200
        rows = await db.execute_fetchall(
            "SELECT status, previous_status, resolved_at FROM action_cards WHERE card_id = ?",
            ("card_test",),
        )
        assert rows[0]["status"] == "pending"        # restored
        assert rows[0]["previous_status"] is None     # consumed
        assert rows[0]["resolved_at"] is None         # cleared

    async def test_reopen_archived_bypasses_forward_only(self, db):
        """An archived card has NO valid forward transitions, but reopen still works
        because it goes through the SSOT with allow_restore=True (P7-4)."""
        await insert_test_card(db, status="archived")
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/cards/card_test/reopen")

        assert resp.status_code == 200
        rows = await db.execute_fetchall(
            "SELECT status FROM action_cards WHERE card_id = ?", ("card_test",)
        )
        assert rows[0]["status"] == "pending"  # no previous_status → full reprocess


@pytest.mark.asyncio
class TestFeedSearch:
    """GET /cards/grouped?search= — perf-only refactor keeps substring matching,
    de-correlates the tag lookup, and drops the giant JSON-blob fields (P4-10)."""

    async def _search_ids(self, term):
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get(f"/cards/grouped?search={term}")
        assert resp.status_code == 200
        data = resp.json()
        return {c["card_id"] for g in data["groups"] for c in g["cards"]}

    async def test_substring_match_preserved(self, db):
        """A partial-word term still matches via LIKE substring (not FTS tokens)."""
        await insert_test_card(
            db, "card_q", "evt_q", header="Quokkapayment overdue", summary="none",
            entity_id="jira:ticket:Q-1",
        )
        # 'quokka' is a substring of the header token 'Quokkapayment' — a token/FTS
        # search would miss it; substring LIKE must still find it.
        assert "card_q" in await self._search_ids("quokka")

    async def test_tag_name_match_decorrelated(self, db):
        """Searching a tag name matches via the hoisted ctag join."""
        await insert_test_card(
            db, "card_t", "evt_t", header="Nothing special", summary="none",
            entity_id="jira:ticket:T-1",
        )
        cur = await db.execute(
            "INSERT INTO tags (name, color) VALUES (?, ?)", ("wafflewatch", "#0f0")
        )
        await db.execute(
            "INSERT INTO tag_assignments (tag_id, target_type, target_id) VALUES (?, 'card', ?)",
            (cur.lastrowid, "card_t"),
        )
        await db.commit()
        assert "card_t" in await self._search_ids("wafflewatch")
        # A card without the tag is not returned for that term.
        assert await self._search_ids("wafflewatch") == {"card_t"}

    async def test_staged_output_no_longer_searched(self, db):
        """Terms that appear only in staged_output/suggested_actions don't match.

        insert_test_card's default staged_output is {"content": "Add null check"};
        'checkzzz' is a unique token so we can prove the field is no longer scanned
        without a false positive from other columns."""
        await insert_test_card(
            db, "card_s", "evt_s", header="Plain header", summary="plain",
            entity_id="jira:ticket:S-1",
            actions=[{"action_id": "a1", "label": "do", "action_type": "comment",
                      "target_platform": "jira", "payload": {"body": "checkzzz here"}}],
        )
        # 'checkzzz' lives only in suggested_actions JSON → dropped from search.
        assert "card_s" not in await self._search_ids("checkzzz")
        # Sanity: a term in a retained field (header) still matches.
        assert "card_s" in await self._search_ids("plain")


@pytest.mark.asyncio
class TestGroupedPayloadSlim:
    """/cards/grouped ships a slim list payload (P4-9): staged_output +
    suggested_actions dropped, intelligence kept; the detail route stays full."""

    async def test_grouped_omits_heavy_blobs_but_keeps_intelligence(self, db):
        await insert_test_card(db, "card_slim", "evt_slim")  # default fixture has all 3

        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            grouped = await client.get("/cards/grouped")
            detail = await client.get("/cards/card_slim")

        assert grouped.status_code == 200 and detail.status_code == 200
        card = next(
            c for g in grouped.json()["groups"] for c in g["cards"] if c["card_id"] == "card_slim"
        )
        # Slimmed in the list payload...
        assert card["staged_output"] is None
        assert card["suggested_actions"] is None
        # ...but intelligence is kept (small + client-searchable).
        assert card["intelligence"] == ["Finding 1", "Finding 2"]

        # The detail endpoint still returns the full heavy fields.
        full = detail.json()
        assert full["staged_output"] is not None
        assert full["suggested_actions"] is not None


@pytest.mark.asyncio
class TestGroupedPagination:
    """/cards/grouped caps groups with limit/offset + has_more (P4-9 part b)."""

    async def _insert_n_groups(self, db, n):
        for i in range(n):
            await insert_test_card(
                db, card_id=f"card_{i}", event_id=f"evt_{i}",
                entity_id=f"jira:ticket:PAGE-{i}",
            )

    async def test_limit_caps_and_reports_has_more(self, db):
        await self._insert_n_groups(db, 3)
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            page1 = (await client.get("/cards/grouped?limit=2&offset=0")).json()
            page2 = (await client.get("/cards/grouped?limit=2&offset=2")).json()

        # total_groups is the FULL count regardless of the page window.
        assert page1["total_groups"] == 3
        assert len(page1["groups"]) == 2
        assert page1["has_more"] is True

        assert page2["total_groups"] == 3
        assert len(page2["groups"]) == 1
        assert page2["has_more"] is False

        # The two pages cover distinct groups (no overlap, full coverage).
        ids1 = {g["entity_id"] for g in page1["groups"]}
        ids2 = {g["entity_id"] for g in page2["groups"]}
        assert ids1.isdisjoint(ids2)
        assert len(ids1 | ids2) == 3

    async def test_default_limit_returns_all_when_under_cap(self, db):
        await self._insert_n_groups(db, 3)
        from laya.main import app
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            data = (await client.get("/cards/grouped")).json()
        assert data["total_groups"] == 3
        assert len(data["groups"]) == 3
        assert data["has_more"] is False  # 3 < default cap of 200


@pytest.mark.asyncio
class TestRunEntityAgentResume:
    """POST /entity/{id}/run-agent resuming an existing workspace (issue #43)."""

    ENTITY = "jira:ticket:RES-7"

    async def _resume(self, db, body: dict) -> str:
        """Call the endpoint against a completed prior session; return the resume text."""
        from contextlib import ExitStack
        from unittest.mock import MagicMock

        await insert_test_card(db, "card_res", "evt_res", entity_id=self.ENTITY)
        sm = "laya.agents.session_manager"
        ec = "laya.agents.entity_context"
        resume = AsyncMock(return_value=MagicMock())
        with ExitStack() as stack:
            p = stack.enter_context
            p(patch("laya.config.load_settings", return_value={"coding_agent": "claude_code"}))
            p(patch(f"{sm}.get_session_for_entity",
                    new=AsyncMock(return_value={"session_id": "sess_old", "status": "completed"})))
            p(patch(f"{sm}.has_unanswered_questions", new=AsyncMock(return_value=False)))
            p(patch(f"{sm}.resume_conversation", new=resume))
            p(patch(f"{sm}.start_session", new=AsyncMock()))
            p(patch(f"{ec}.write_entity_context_file", new=AsyncMock()))
            p(patch(f"{ec}.get_entity_research_dir", new=MagicMock(return_value="/tmp/research/ent")))
            p(patch("laya.workers.engineer.resolve_entity_repo_path", new=AsyncMock(return_value=(None, []))))
            p(patch("laya.config.load_repos", new=MagicMock(return_value={"repos": []})))
            p(patch("laya.api.cards_agent._stream_entity_agent", new=MagicMock()))
            p(patch("laya.api.cards_agent.create_tracked_task", new=MagicMock()))

            from laya.main import app
            transport = ASGITransport(app=app)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(f"/entity/{self.ENTITY}/run-agent", json=body)

        assert resp.status_code == 200, resp.text
        assert resp.json()["session_id"] == "sess_old"
        resume.assert_awaited_once()
        assert resume.await_args.args[0] == "sess_old"
        return resume.await_args.args[1]

    async def test_custom_prompt_keeps_context_reminder(self, db):
        """A custom resume prompt is appended with the CONTEXT.md reminder, not sent alone."""
        text = await self._resume(db, {"prompt": "Is this ticket a duplicate?"})
        assert text.startswith("Is this ticket a duplicate?")
        assert "CONTEXT.md" in text

    async def test_no_prompt_uses_default_reminder(self, db):
        text = await self._resume(db, {})
        assert text.startswith("Continue working.")
        assert "CONTEXT.md" in text


@pytest.mark.asyncio
class TestRunEntityAgentRepo:
    """POST /entity/{id}/run-agent starts the agent in the resolved repo (issue #46)."""

    ENTITY = "jira:ticket:INV-7"

    async def test_new_session_uses_resolved_repo(self, db):
        from contextlib import ExitStack
        from unittest.mock import MagicMock

        await insert_test_card(db, "card_inv", "evt_inv", entity_id=self.ENTITY)
        sm = "laya.agents.session_manager"
        ec = "laya.agents.entity_context"
        start = AsyncMock(return_value=("sess_new", MagicMock()))
        resolve = AsyncMock(return_value=("/tmp/repo-b", ["/tmp/repo-a"]))
        with ExitStack() as stack:
            p = stack.enter_context
            p(patch("laya.config.load_settings", return_value={"coding_agent": "claude_code"}))
            p(patch(f"{sm}.get_session_for_entity", new=AsyncMock(return_value=None)))
            p(patch(f"{sm}.has_unanswered_questions", new=AsyncMock(return_value=False)))
            p(patch(f"{sm}.start_session", new=start))
            p(patch(f"{ec}.write_entity_context_file", new=AsyncMock()))
            p(patch(f"{ec}.get_entity_research_dir", new=MagicMock(return_value="/tmp/research/ent")))
            p(patch("laya.workers.engineer.resolve_entity_repo_path", new=resolve))
            p(patch("laya.api.cards_agent._stream_entity_agent", new=MagicMock()))
            p(patch("laya.api.cards_agent.create_tracked_task", new=MagicMock()))

            from laya.main import app
            transport = ASGITransport(app=app)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(f"/entity/{self.ENTITY}/run-agent", json={})

        assert resp.status_code == 200, resp.text
        # The resolver is given the entity + its space, not a fabricated classification.
        resolve.assert_awaited_once_with(self.ENTITY, space_id="default")
        kwargs = start.await_args.kwargs
        assert kwargs["repo_path"] == "/tmp/repo-b"
        assert kwargs["add_dirs"] == ["/tmp/research/ent", "/tmp/repo-a"]
